(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function n(e){"@swc/helpers - typeof";return e&&typeof Symbol<`u`&&e.constructor===Symbol?`symbol`:typeof e}var r={SparklesIcon:[`MagicWandIcon`],SparkleIcon:[`MagicWandIcon`]};function i(...e){return o(e,!1)}function a(e){try{return e()}catch{return}}function o(e,i){var o=function(e){var n=a(function(){return c(e)||void 0}),r=a(function(){return f?.(e)});if(i)return d&&(r||n)?{v:/*#__PURE__*/ (0,t.jsx)(d,{source:n,IconComponent:r,variant:`danger`})}:`continue`;if(n&&d)return{v:/*#__PURE__*/ (0,t.jsx)(d,{source:n})};if(r)return{v:/*#__PURE__*/ (0,t.jsx)(r,{})}},s=[...new Set(e.flatMap(function(e){return[e,...r[e]??[]]}))],{getAssetIdByName:c}=valenced.assets,{TableRow:l,TableRowIcon:u}=valenced.discord.design.Design,d=l?.Icon??u,f=a(function(){return valenced.utils.discord.lookupGeneratedIconComponent});for(var p of s){var m=o(p);if(n(m)===`object`)return m.v}}function s(e=16){try{var{useSafeAreaInsets:t,initialWindowMetrics:n}=valenced.externals.ReactNativeSafeAreaContext.ReactNativeSafeAreaContext,r=t()?.bottom??0,i=n?.insets?.bottom??0;return Math.max(r,i)+e}catch{}return e}var c=20,l,u=[],d=/* @__PURE__ */ new Set;function f(e){if(l=e,e)for(var t of u.splice(0))m(t)}function p(e,t){var n=h(e,t),r=n instanceof Error?n.message:String(n);d.has(r)||(d.add(r),l?m(n):u.length<c&&u.push(n))}function m(e){try{l?.reportError(e)}catch{}}function h(e,t){if(t===void 0)return Error(e);if(!e)return t;var n=t instanceof Error?t.message:String(t),r=/* @__PURE__ */ Error(`${e} ${n}`);if(t instanceof Error&&typeof t.stack==`string`){var i=t.stack.split(`
`).slice(1).join(`
`);i&&(r.stack=`${r.name}: ${r.message}\n${i}`)}return r}var g,_=`changelogSeenVersion`,v=3,y=function(e){return`${e}.changelog`};function b(e){return typeof e==`string`?e:e&&Array.isArray(e.nums)?e.nums.join(`.`)+(e.label?`-${e.label}`:``):String(e??``)}function ee(e){var[t,n]=String(e).split(`-`,2);return{nums:t.split(`.`).map(function(e){return Number.parseInt(e,10)||0}),pre:n}}function x(e,t){for(var n=ee(e),r=ee(t),i=0;i<Math.max(n.nums.length,r.nums.length);i++){var a=(n.nums[i]??0)-(r.nums[i]??0);if(a)return a}return n.pre===r.pre?0:n.pre===void 0?1:r.pre===void 0?-1:n.pre.localeCompare(r.pre,void 0,{numeric:!0})}function te(e,t,n={}){var r=e.plugin.manifest,i={id:r.id,name:r.name??r.id,current:b(r.version),entries:[...t].sort(function(e,t){return x(t.version,e.version)}),storage:e.jsonStorage,latestOnly:n.latestOnly};g=i;var a=le(i);return ne(i).catch(function(e){return p(`[${i.name}] changelog check failed:`,e)}),function(){g===i&&(g=void 0),a()}}async function ne(e){if(e.storage){var t=await e.storage.get(),n=t?.[_]?b(t[_]):void 0;if(n!==e.current){if(!n||x(e.current,n)<0)await e.storage.set({[_]:e.current});else{var r=e.entries.filter(function(t){return x(t.version,n)>0&&x(t.version,e.current)<=0});r.length?e.pending=e.latestOnly?r.slice(0,1):r:await e.storage.set({[_]:e.current})}}}}function re(e={}){var{React:n}=valenced.react,{useNavigation:r}=valenced.externals.ReactNavigation.ReactNavigationNative,i=r(),a=e.header!==!1;n.useLayoutEffect(function(){a&&g&&i.setOptions?.({headerRight:function(){return/*#__PURE__*/ (0,t.jsx)(ie,{})}})},[a]),n.useEffect(function(){var e=g;if(e?.pending?.length){var t=e.pending;e.pending=void 0,se(e,t,function(){return i.navigate(y(e.id))}),e.storage?.set({[_]:e.current}).catch(function(t){return p(`[${e.name}] could not save the seen version:`,t)})}},[])}function ie(){var{Pressable:e}=valenced.react.ReactNative,{useNavigation:n}=valenced.externals.ReactNavigation.ReactNavigationNative,r=n(),a=g;return a?/*#__PURE__*/ (0,t.jsx)(e,{accessibilityRole:`button`,accessibilityLabel:`Changelog`,hitSlop:12,onPress:function(){return r.navigate(y(a.id))},style:function({pressed:e}){return{paddingHorizontal:12,opacity:e?.5:1}},children:i(`ClockIcon`,`ic_clock`)}):null}function ae({changes:e}){var{View:n}=valenced.react.ReactNative,{Text:r}=valenced.discord.design.Design;return/*#__PURE__*/ (0,t.jsx)(n,{style:{gap:4},children:e.map(function(e,i){return/*#__PURE__*/ (0,t.jsxs)(n,{style:{flexDirection:`row`},children:[/*#__PURE__*/ (0,t.jsx)(r,{variant:`text-sm/normal`,color:`text-muted`,style:{width:14},children:`•`}),/*#__PURE__*/ (0,t.jsx)(r,{variant:`text-sm/normal`,color:`text-muted`,style:{flex:1},children:e})]},i)})})}function oe(e){return e.title?`${e.version} · ${e.title}`:e.version}function se(e,n,r){var{ScrollView:i,View:a,Dimensions:o}=valenced.react.ReactNative,{AlertModal:s,AlertActionButton:c,Text:l}=valenced.discord.design.Design,u=valenced.discord.actions.AlertActionCreators,d=`bleelblep-whats-new-${e.id}`,f=function(){return u.dismissAlert(d)},m=n.slice(0,v),h=n.length-m.length,g=/*#__PURE__*/ (0,t.jsx)(i,{style:{maxHeight:Math.round(o.get(`window`).height*.5)},nestedScrollEnabled:!0,children:/*#__PURE__*/ (0,t.jsxs)(a,{style:{gap:12},children:[m.map(function(e){return/*#__PURE__*/ (0,t.jsxs)(a,{style:{gap:4},children:[/*#__PURE__*/ (0,t.jsx)(l,{variant:`text-sm/semibold`,color:`text-default`,children:oe(e)}),/*#__PURE__*/ (0,t.jsx)(ae,{changes:e.changes})]},e.version)}),h>0?/*#__PURE__*/ (0,t.jsxs)(l,{variant:`text-sm/normal`,color:`text-muted`,children:[`And `,h,` more version`,h===1?``:`s`,` in the full changelog.`]}):null]})});try{u.openAlert(d,/*#__PURE__*/ (0,t.jsx)(s,{title:`What's new in ${e.name} ${e.current}`,extraContent:g,actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(c,{text:`Full changelog`,variant:`primary`,onPress:function(){f(),r()}}),/*#__PURE__*/ (0,t.jsx)(c,{text:`Close`,variant:`secondary`,onPress:f})]})}))}catch(t){p(`[${e.name}] couldn't show what's new:`,t)}}function ce(){var e=valenced.discord.modules.settings;typeof e.refreshSettings==`function`?e.refreshSettings():(e.refreshSettingsNavigator?.(),e.refreshSettingsOverviewScreen?.())}function le(e){var{registerSettingsItem:t,onSettingsModulesLoaded:n}=valenced.discord.modules.settings,r=y(e.id),i,a=n(function(){i=t(r,{parent:null,type:`route`,useTitle:function(){return`Changelog`},screen:{route:r,getComponent:function(){return ue}}}),ce()});return function(){a(),i?.(),i=void 0,ce()}}function ue(){var{Page:e}=valenced.components,{ScrollView:n,View:r}=valenced.react.ReactNative,{Stack:i,Text:a,TableRowGroup:o,TableRow:c}=valenced.discord.design.Design,l=s(),u=g;return u?/*#__PURE__*/ (0,t.jsx)(e,{children:/*#__PURE__*/ (0,t.jsx)(n,{contentContainerStyle:{paddingBottom:l},children:/*#__PURE__*/ (0,t.jsxs)(i,{spacing:24,children:[/*#__PURE__*/ (0,t.jsxs)(a,{color:`text-muted`,variant:`text-sm/normal`,children:[`Every version of `,u.name,`, newest first. You have `,u.current,`.`]}),u.entries.map(function(e){var n=e.version===u.current?` · installed`:``;return/*#__PURE__*/ (0,t.jsx)(o,{title:`${e.version}${n}${e.date?` · ${e.date}`:``}`,children:/*#__PURE__*/ (0,t.jsx)(c,{label:e.title??`Version ${e.version}`,subLabel:/*#__PURE__*/ (0,t.jsx)(r,{style:{marginTop:6},children:/*#__PURE__*/ (0,t.jsx)(ae,{changes:e.changes})})})},e.version)})]})})}):null}var de=[{version:`0.3.0`,date:`2026-11-08`,title:`Their time on their profile`,changes:[`Open someone's profile and their local time is right there in a Local time card, once their timezone is known. Tap it to change their timezone.`,`Don’t want it? Turn off "Show on their profile" in the settings.`]},{version:`0.2.9`,date:`2026-11-02`,title:`Credit line`,changes:[`The foot of the settings now reads "Made by aniimalz", who made the original, with a smaller "Ported by bleelblep" underneath.`]},{version:`0.2.8`,date:`2026-11-02`,title:`Tidier settings`,changes:[`The people you've set are at the top of the settings, before the options.`,`Tapping someone in the list opens a small menu to change their timezone or remove them.`,`The note at the top can be hidden for good with "Don't show again".`]},{version:`0.2.7`,date:`2026-11-01`,title:`Made by`,changes:[`A small "Made by bleelblep" line at the foot of the settings page.`]},{version:`0.2.6`,date:`2026-10-30`,title:`In the profile menu`,changes:[`Set timezone (or their time, once set) is in the ⋯ menu on someone's profile.`,`New switch, "Show in message menu" (on by default): turn it off to take the row out of the message long-press menu.`]},{version:`0.2.5`,date:`2026-10-30`,title:`Links stay links`,changes:[`A message that is only a link keeps its blue, tappable link after you set that person's timezone.`,`The timezone row is now at the bottom of the long-press menu instead of the top.`]},{version:`0.2.4`,date:`2026-10-28`,title:`Equicord's list`,changes:[`New switch, "Also use Equicord's list" (off by default): shows the timezones people set in Equicord, for anyone without one from you or the shared list. Read only.`]},{version:`0.2.3`,date:`2026-10-28`,title:`Quieter when offline`,changes:[`When the shared timezone list can't be reached, it waits before asking again (30 seconds, up to 10 minutes) instead of asking constantly, and shows one error instead of many.`]},{version:`0.2.2`,date:`2026-10-28`,title:`Bazinga Plugins`,changes:[`Now published from the Bazinga Plugins repository.`]},{version:`0.2.1`,date:`2026-10-26`,title:`Valenced`,changes:[`Ported to Valenced. Settings from Revenge don't carry over.`]},{version:`0.2.0`,date:`2026-10-25`,title:`Search any country or city`,changes:[`Type a country (Kenya, UK, New Zealand) to get its timezones, even offline.`,`Every timezone is searchable now, by city, region (Indiana) or old name (Calcutta).`,`Any town or city works too, found online through Open-Meteo. Turn it off under Lookups.`,`The place you pick is saved and shown, like "Mombasa, Kenya".`]},{version:`0.1.3`,date:`2026-10-23`,title:`Discord version limit removed`,changes:[`Installs on any Discord version again.`]},{version:`0.1.2`,date:`2026-10-22`,title:`Discord 352.2`,changes:[`Also starts on Discord 352.2 (was 351.6 or older).`]},{version:`0.1.1`,date:`2026-10-21`,title:`Discord version limit`,changes:[`Only starts on Discord 351.6 or older, so a newer Discord build can't break it.`]},{version:`0.1.0`,date:`2026-10-15`,title:`First version`,changes:[`Set someone's timezone from the message long-press menu or settings.`,`Their local time shows after the timestamp on their messages, with their weekday when it differs.`,`People you haven't set can come from the shared timezone list, which you can turn off.`]}];function fe(e,t,n,r=`[modules]`){var i=!1,a=[],o=function(){for(var e of a.splice(0))try{e()}catch{}},s=function(t,a){if(!i&&t){i=!0,Promise.resolve().then(o);try{n(t)}catch(t){p(`${r} patching ${e} failed:`,t)}}};try{var c=valenced.discord.utils.modules.finders;a.push(c.getModuleWithImportedPath(e,function(e){return s(e,`path`)}))}catch(t){p(`${r} path lookup for ${e} failed:`,t)}if(!i&&t)try{a.push(valenced.modules.finders.getModules(t,function(e){return s(e,`name`)},{returnNamespace:!0}))}catch(t){p(`${r} name lookup for ${e} failed:`,t)}return function(){i=!0,o()}}var pe=`[Timezones]`,me=` ​`,he,ge=!1;function _e(){var{withProps:e}=valenced.modules.finders.filters,t=function(e){if(e){if(typeof e?.getOrCreate==`function`&&typeof e?.commit==`function`)return e;if(typeof e?.default?.getOrCreate==`function`&&typeof e?.default?.commit==`function`)return e.default;if(typeof e?._channelMessages?.getOrCreate==`function`&&typeof e?._channelMessages?.commit==`function`)return e._channelMessages}};return fe(`lib/ChannelMessages.tsx`,e(`getOrCreate`,`commit`),function(e){var n=t(e);n&&(he=n)},pe)}function ve(e,t){try{var n=he;if(!n)return!1;var r=n.getOrCreate(e);if(typeof r?.has!=`function`||!r.has(t)||typeof r.update!=`function`)return!1;var i=r.update(t,function(e){try{if(e?.id!==t)return e;var n=Object.create(Object.getPrototypeOf(e));return Object.defineProperties(n,Object.getOwnPropertyDescriptors(e)),typeof n.content==`string`&&(n.content=n.content.endsWith(me)?n.content.slice(0,-me.length):n.content+me),n}catch{return e}});return n.commit(i),ge||(ge=!0,queueMicrotask(function(){ge=!1;try{valenced.discord.flux.Stores.MessageStore?.emitChange?.()}catch(e){p(`${pe} redraw emit failed:`,e)}})),!0}catch(e){return p(`${pe} redraw failed:`,e),!1}}var ye={AD:`Andorra`,AE:`United Arab Emirates`,AF:`Afghanistan`,AG:`Antigua & Barbuda`,AI:`Anguilla`,AL:`Albania`,AM:`Armenia`,AO:`Angola`,AQ:`Antarctica`,AR:`Argentina`,AS:`Samoa (American)`,AT:`Austria`,AU:`Australia`,AW:`Aruba`,AX:`Åland Islands`,AZ:`Azerbaijan`,BA:`Bosnia & Herzegovina`,BB:`Barbados`,BD:`Bangladesh`,BE:`Belgium`,BF:`Burkina Faso`,BG:`Bulgaria`,BH:`Bahrain`,BI:`Burundi`,BJ:`Benin`,BL:`St Barthelemy`,BM:`Bermuda`,BN:`Brunei`,BO:`Bolivia`,BQ:`Caribbean NL`,BR:`Brazil`,BS:`Bahamas`,BT:`Bhutan`,BV:`Bouvet Island`,BW:`Botswana`,BY:`Belarus`,BZ:`Belize`,CA:`Canada`,CC:`Cocos (Keeling) Islands`,CD:`Congo (Dem. Rep.)`,CF:`Central African Rep.`,CG:`Congo (Rep.)`,CH:`Switzerland`,CI:`Côte d’Ivoire`,CK:`Cook Islands`,CL:`Chile`,CM:`Cameroon`,CN:`China`,CO:`Colombia`,CR:`Costa Rica`,CU:`Cuba`,CV:`Cape Verde`,CW:`Curaçao`,CX:`Christmas Island`,CY:`Cyprus`,CZ:`Czech Republic`,DE:`Germany`,DJ:`Djibouti`,DK:`Denmark`,DM:`Dominica`,DO:`Dominican Republic`,DZ:`Algeria`,EC:`Ecuador`,EE:`Estonia`,EG:`Egypt`,EH:`Western Sahara`,ER:`Eritrea`,ES:`Spain`,ET:`Ethiopia`,FI:`Finland`,FJ:`Fiji`,FK:`Falkland Islands`,FM:`Micronesia`,FO:`Faroe Islands`,FR:`France`,GA:`Gabon`,GB:`Britain (UK)`,GD:`Grenada`,GE:`Georgia`,GF:`French Guiana`,GG:`Guernsey`,GH:`Ghana`,GI:`Gibraltar`,GL:`Greenland`,GM:`Gambia`,GN:`Guinea`,GP:`Guadeloupe`,GQ:`Equatorial Guinea`,GR:`Greece`,GS:`South Georgia & the South Sandwich Islands`,GT:`Guatemala`,GU:`Guam`,GW:`Guinea-Bissau`,GY:`Guyana`,HK:`Hong Kong`,HM:`Heard Island & McDonald Islands`,HN:`Honduras`,HR:`Croatia`,HT:`Haiti`,HU:`Hungary`,ID:`Indonesia`,IE:`Ireland`,IL:`Israel`,IM:`Isle of Man`,IN:`India`,IO:`British Indian Ocean Territory`,IQ:`Iraq`,IR:`Iran`,IS:`Iceland`,IT:`Italy`,JE:`Jersey`,JM:`Jamaica`,JO:`Jordan`,JP:`Japan`,KE:`Kenya`,KG:`Kyrgyzstan`,KH:`Cambodia`,KI:`Kiribati`,KM:`Comoros`,KN:`St Kitts & Nevis`,KP:`Korea (North)`,KR:`Korea (South)`,KW:`Kuwait`,KY:`Cayman Islands`,KZ:`Kazakhstan`,LA:`Laos`,LB:`Lebanon`,LC:`St Lucia`,LI:`Liechtenstein`,LK:`Sri Lanka`,LR:`Liberia`,LS:`Lesotho`,LT:`Lithuania`,LU:`Luxembourg`,LV:`Latvia`,LY:`Libya`,MA:`Morocco`,MC:`Monaco`,MD:`Moldova`,ME:`Montenegro`,MF:`St Martin (French)`,MG:`Madagascar`,MH:`Marshall Islands`,MK:`North Macedonia`,ML:`Mali`,MM:`Myanmar (Burma)`,MN:`Mongolia`,MO:`Macau`,MP:`Northern Mariana Islands`,MQ:`Martinique`,MR:`Mauritania`,MS:`Montserrat`,MT:`Malta`,MU:`Mauritius`,MV:`Maldives`,MW:`Malawi`,MX:`Mexico`,MY:`Malaysia`,MZ:`Mozambique`,NA:`Namibia`,NC:`New Caledonia`,NE:`Niger`,NF:`Norfolk Island`,NG:`Nigeria`,NI:`Nicaragua`,NL:`Netherlands`,NO:`Norway`,NP:`Nepal`,NR:`Nauru`,NU:`Niue`,NZ:`New Zealand`,OM:`Oman`,PA:`Panama`,PE:`Peru`,PF:`French Polynesia`,PG:`Papua New Guinea`,PH:`Philippines`,PK:`Pakistan`,PL:`Poland`,PM:`St Pierre & Miquelon`,PN:`Pitcairn`,PR:`Puerto Rico`,PS:`Palestine`,PT:`Portugal`,PW:`Palau`,PY:`Paraguay`,QA:`Qatar`,RE:`Réunion`,RO:`Romania`,RS:`Serbia`,RU:`Russia`,RW:`Rwanda`,SA:`Saudi Arabia`,SB:`Solomon Islands`,SC:`Seychelles`,SD:`Sudan`,SE:`Sweden`,SG:`Singapore`,SH:`St Helena`,SI:`Slovenia`,SJ:`Svalbard & Jan Mayen`,SK:`Slovakia`,SL:`Sierra Leone`,SM:`San Marino`,SN:`Senegal`,SO:`Somalia`,SR:`Suriname`,SS:`South Sudan`,ST:`Sao Tome & Principe`,SV:`El Salvador`,SX:`St Maarten (Dutch)`,SY:`Syria`,SZ:`Eswatini (Swaziland)`,TC:`Turks & Caicos Is`,TD:`Chad`,TF:`French S. Terr.`,TG:`Togo`,TH:`Thailand`,TJ:`Tajikistan`,TK:`Tokelau`,TL:`East Timor`,TM:`Turkmenistan`,TN:`Tunisia`,TO:`Tonga`,TR:`Turkey`,TT:`Trinidad & Tobago`,TV:`Tuvalu`,TW:`Taiwan`,TZ:`Tanzania`,UA:`Ukraine`,UG:`Uganda`,UM:`US minor outlying islands`,US:`United States`,UY:`Uruguay`,UZ:`Uzbekistan`,VA:`Vatican City`,VC:`St Vincent`,VE:`Venezuela`,VG:`Virgin Islands (UK)`,VI:`Virgin Islands (US)`,VN:`Vietnam`,VU:`Vanuatu`,WF:`Wallis & Futuna`,WS:`Samoa (western)`,YE:`Yemen`,YT:`Mayotte`,ZA:`South Africa`,ZM:`Zambia`,ZW:`Zimbabwe`},be=`AD|Europe/Andorra|
AE|Asia/Dubai|
AF|Asia/Kabul|
AG|America/Antigua|
AI|America/Anguilla|
AL|Europe/Tirane|
AM|Asia/Yerevan|
AO|Africa/Luanda|
AQ|Antarctica/McMurdo|New Zealand time - McMurdo, South Pole
AQ|Antarctica/Casey|Casey
AQ|Antarctica/Davis|Davis
AQ|Antarctica/DumontDUrville|Dumont-d'Urville
AQ|Antarctica/Mawson|Mawson
AQ|Antarctica/Palmer|Palmer
AQ|Antarctica/Rothera|Rothera
AQ|Antarctica/Syowa|Syowa
AQ|Antarctica/Troll|Troll
AQ|Antarctica/Vostok|Vostok
AR|America/Argentina/Buenos_Aires|Buenos Aires (BA, CF)
AR|America/Argentina/Cordoba|Argentina (most areas: CB, CC, CN, ER, FM, MN, SE, SF)
AR|America/Argentina/Salta|Salta (SA, LP, NQ, RN)
AR|America/Argentina/Jujuy|Jujuy (JY)
AR|America/Argentina/Tucuman|Tucuman (TM)
AR|America/Argentina/Catamarca|Catamarca (CT), Chubut (CH)
AR|America/Argentina/La_Rioja|La Rioja (LR)
AR|America/Argentina/San_Juan|San Juan (SJ)
AR|America/Argentina/Mendoza|Mendoza (MZ)
AR|America/Argentina/San_Luis|San Luis (SL)
AR|America/Argentina/Rio_Gallegos|Santa Cruz (SC)
AR|America/Argentina/Ushuaia|Tierra del Fuego (TF)
AS|Pacific/Pago_Pago|
AT|Europe/Vienna|
AU|Australia/Lord_Howe|Lord Howe Island
AU|Antarctica/Macquarie|Macquarie Island
AU|Australia/Hobart|Tasmania
AU|Australia/Melbourne|Victoria
AU|Australia/Sydney|New South Wales (most areas)
AU|Australia/Broken_Hill|New South Wales (Yancowinna)
AU|Australia/Brisbane|Queensland (most areas)
AU|Australia/Lindeman|Queensland (Whitsunday Islands)
AU|Australia/Adelaide|South Australia
AU|Australia/Darwin|Northern Territory
AU|Australia/Perth|Western Australia (most areas)
AU|Australia/Eucla|Western Australia (Eucla)
AW|America/Aruba|
AX|Europe/Mariehamn|
AZ|Asia/Baku|
BA|Europe/Sarajevo|
BB|America/Barbados|
BD|Asia/Dhaka|
BE|Europe/Brussels|
BF|Africa/Ouagadougou|
BG|Europe/Sofia|
BH|Asia/Bahrain|
BI|Africa/Bujumbura|
BJ|Africa/Porto-Novo|
BL|America/St_Barthelemy|
BM|Atlantic/Bermuda|
BN|Asia/Brunei|
BO|America/La_Paz|
BQ|America/Kralendijk|
BR|America/Noronha|Atlantic islands
BR|America/Belem|Para (east), Amapa
BR|America/Fortaleza|Brazil (northeast: MA, PI, CE, RN, PB)
BR|America/Recife|Pernambuco
BR|America/Araguaina|Tocantins
BR|America/Maceio|Alagoas, Sergipe
BR|America/Bahia|Bahia
BR|America/Sao_Paulo|Brazil (southeast: GO, DF, MG, ES, RJ, SP, PR, SC, RS)
BR|America/Campo_Grande|Mato Grosso do Sul
BR|America/Cuiaba|Mato Grosso
BR|America/Santarem|Para (west)
BR|America/Porto_Velho|Rondonia
BR|America/Boa_Vista|Roraima
BR|America/Manaus|Amazonas (east)
BR|America/Eirunepe|Amazonas (west)
BR|America/Rio_Branco|Acre
BS|America/Nassau|
BT|Asia/Thimphu|
BW|Africa/Gaborone|
BY|Europe/Minsk|
BZ|America/Belize|
CA|America/St_Johns|Newfoundland, Labrador (SE)
CA|America/Halifax|Atlantic - NS (most areas), PE
CA|America/Glace_Bay|Atlantic - NS (Cape Breton)
CA|America/Moncton|Atlantic - New Brunswick
CA|America/Goose_Bay|Atlantic - Labrador (most areas)
CA|America/Blanc-Sablon|AST - QC (Lower North Shore)
CA|America/Toronto|Eastern - ON & QC (most areas)
CA|America/Iqaluit|Eastern - NU (most areas)
CA|America/Atikokan|EST - ON (Atikokan), NU (Coral H)
CA|America/Winnipeg|EST - Manitoba, ON (northwest)
CA|America/Resolute|Central - NU (Resolute)
CA|America/Rankin_Inlet|Central - NU (central)
CA|America/Regina|CST - SK (most areas)
CA|America/Swift_Current|CST - SK (midwest)
CA|America/Edmonton|CST - AB, BC(E), NT(E), SK(W)
CA|America/Cambridge_Bay|Mountain - NU (west)
CA|America/Inuvik|CST - NT (west)
CA|America/Vancouver|MST - BC (most areas)
CA|America/Creston|MST - BC (Creston)
CA|America/Dawson_Creek|MST - BC (Dawson Cr, Ft St John)
CA|America/Fort_Nelson|MST - BC (Ft Nelson)
CA|America/Whitehorse|MST - Yukon (east)
CA|America/Dawson|MST - Yukon (west)
CC|Indian/Cocos|
CD|Africa/Kinshasa|Dem. Rep. of Congo (west)
CD|Africa/Lubumbashi|Dem. Rep. of Congo (east)
CF|Africa/Bangui|
CG|Africa/Brazzaville|
CH|Europe/Zurich|
CI|Africa/Abidjan|
CK|Pacific/Rarotonga|
CL|America/Santiago|most of Chile
CL|America/Coyhaique|Aysen Region
CL|America/Punta_Arenas|Magallanes Region
CL|Pacific/Easter|Easter Island
CM|Africa/Douala|
CN|Asia/Shanghai|Beijing Time
CN|Asia/Urumqi|Xinjiang Time
CO|America/Bogota|
CR|America/Costa_Rica|
CU|America/Havana|
CV|Atlantic/Cape_Verde|
CW|America/Curacao|
CX|Indian/Christmas|
CY|Asia/Nicosia|most of Cyprus
CY|Asia/Famagusta|Northern Cyprus
CZ|Europe/Prague|
DE|Europe/Berlin|most of Germany
DE|Europe/Busingen|Busingen
DJ|Africa/Djibouti|
DK|Europe/Copenhagen|
DM|America/Dominica|
DO|America/Santo_Domingo|
DZ|Africa/Algiers|
EC|America/Guayaquil|Ecuador (mainland)
EC|Pacific/Galapagos|Galapagos Islands
EE|Europe/Tallinn|
EG|Africa/Cairo|
EH|Africa/El_Aaiun|
ER|Africa/Asmara|
ES|Europe/Madrid|Spain (mainland)
ES|Africa/Ceuta|Ceuta, Melilla
ES|Atlantic/Canary|Canary Islands
ET|Africa/Addis_Ababa|
FI|Europe/Helsinki|
FJ|Pacific/Fiji|
FK|Atlantic/Stanley|
FM|Pacific/Chuuk|Chuuk/Truk, Yap
FM|Pacific/Pohnpei|Pohnpei/Ponape
FM|Pacific/Kosrae|Kosrae
FO|Atlantic/Faroe|
FR|Europe/Paris|
GA|Africa/Libreville|
GB|Europe/London|
GD|America/Grenada|
GE|Asia/Tbilisi|
GF|America/Cayenne|
GG|Europe/Guernsey|
GH|Africa/Accra|
GI|Europe/Gibraltar|
GL|America/Nuuk|most of Greenland
GL|America/Danmarkshavn|National Park (east coast)
GL|America/Scoresbysund|Scoresbysund/Ittoqqortoormiit
GL|America/Thule|Thule/Pituffik
GM|Africa/Banjul|
GN|Africa/Conakry|
GP|America/Guadeloupe|
GQ|Africa/Malabo|
GR|Europe/Athens|
GS|Atlantic/South_Georgia|
GT|America/Guatemala|
GU|Pacific/Guam|
GW|Africa/Bissau|
GY|America/Guyana|
HK|Asia/Hong_Kong|
HN|America/Tegucigalpa|
HR|Europe/Zagreb|
HT|America/Port-au-Prince|
HU|Europe/Budapest|
ID|Asia/Jakarta|Java, Sumatra
ID|Asia/Pontianak|Borneo (west, central)
ID|Asia/Makassar|Borneo (east, south), Sulawesi/Celebes, Bali, Nusa Tengarra, Timor (west)
ID|Asia/Jayapura|New Guinea (West Papua / Irian Jaya), Malukus/Moluccas
IE|Europe/Dublin|
IL|Asia/Jerusalem|
IM|Europe/Isle_of_Man|
IN|Asia/Kolkata|
IO|Indian/Chagos|
IQ|Asia/Baghdad|
IR|Asia/Tehran|
IS|Atlantic/Reykjavik|
IT|Europe/Rome|
JE|Europe/Jersey|
JM|America/Jamaica|
JO|Asia/Amman|
JP|Asia/Tokyo|
KE|Africa/Nairobi|
KG|Asia/Bishkek|
KH|Asia/Phnom_Penh|
KI|Pacific/Tarawa|Gilbert Islands
KI|Pacific/Kanton|Phoenix Islands
KI|Pacific/Kiritimati|Line Islands
KM|Indian/Comoro|
KN|America/St_Kitts|
KP|Asia/Pyongyang|
KR|Asia/Seoul|
KW|Asia/Kuwait|
KY|America/Cayman|
KZ|Asia/Almaty|most of Kazakhstan
KZ|Asia/Qyzylorda|Qyzylorda/Kyzylorda/Kzyl-Orda
KZ|Asia/Qostanay|Qostanay/Kostanay/Kustanay
KZ|Asia/Aqtobe|Aqtobe/Aktobe
KZ|Asia/Aqtau|Mangghystau/Mankistau
KZ|Asia/Atyrau|Atyrau/Atirau/Gur'yev
KZ|Asia/Oral|West Kazakhstan
LA|Asia/Vientiane|
LB|Asia/Beirut|
LC|America/St_Lucia|
LI|Europe/Vaduz|
LK|Asia/Colombo|
LR|Africa/Monrovia|
LS|Africa/Maseru|
LT|Europe/Vilnius|
LU|Europe/Luxembourg|
LV|Europe/Riga|
LY|Africa/Tripoli|
MA|Africa/Casablanca|
MC|Europe/Monaco|
MD|Europe/Chisinau|
ME|Europe/Podgorica|
MF|America/Marigot|
MG|Indian/Antananarivo|
MH|Pacific/Majuro|most of Marshall Islands
MH|Pacific/Kwajalein|Kwajalein
MK|Europe/Skopje|
ML|Africa/Bamako|
MM|Asia/Yangon|
MN|Asia/Ulaanbaatar|most of Mongolia
MN|Asia/Hovd|Bayan-Olgii, Hovd, Uvs
MO|Asia/Macau|
MP|Pacific/Saipan|
MQ|America/Martinique|
MR|Africa/Nouakchott|
MS|America/Montserrat|
MT|Europe/Malta|
MU|Indian/Mauritius|
MV|Indian/Maldives|
MW|Africa/Blantyre|
MX|America/Mexico_City|Central Mexico
MX|America/Cancun|Quintana Roo
MX|America/Merida|Campeche, Yucatan
MX|America/Monterrey|Durango; Coahuila, Nuevo Leon, Tamaulipas (most areas)
MX|America/Matamoros|Coahuila, Nuevo Leon, Tamaulipas (US border)
MX|America/Chihuahua|Chihuahua (most areas)
MX|America/Ciudad_Juarez|Chihuahua (US border - west)
MX|America/Ojinaga|Chihuahua (US border - east)
MX|America/Mazatlan|Baja California Sur, Nayarit (most areas), Sinaloa
MX|America/Bahia_Banderas|Bahia de Banderas
MX|America/Hermosillo|Sonora
MX|America/Tijuana|Baja California
MY|Asia/Kuala_Lumpur|Malaysia (peninsula)
MY|Asia/Kuching|Sabah, Sarawak
MZ|Africa/Maputo|
NA|Africa/Windhoek|
NC|Pacific/Noumea|
NE|Africa/Niamey|
NF|Pacific/Norfolk|
NG|Africa/Lagos|
NI|America/Managua|
NL|Europe/Amsterdam|
NO|Europe/Oslo|
NP|Asia/Kathmandu|
NR|Pacific/Nauru|
NU|Pacific/Niue|
NZ|Pacific/Auckland|most of New Zealand
NZ|Pacific/Chatham|Chatham Islands
OM|Asia/Muscat|
PA|America/Panama|
PE|America/Lima|
PF|Pacific/Tahiti|Society Islands
PF|Pacific/Marquesas|Marquesas Islands
PF|Pacific/Gambier|Gambier Islands
PG|Pacific/Port_Moresby|most of Papua New Guinea
PG|Pacific/Bougainville|Bougainville
PH|Asia/Manila|
PK|Asia/Karachi|
PL|Europe/Warsaw|
PM|America/Miquelon|
PN|Pacific/Pitcairn|
PR|America/Puerto_Rico|
PS|Asia/Gaza|Gaza Strip
PS|Asia/Hebron|West Bank
PT|Europe/Lisbon|Portugal (mainland)
PT|Atlantic/Madeira|Madeira Islands
PT|Atlantic/Azores|Azores
PW|Pacific/Palau|
PY|America/Asuncion|
QA|Asia/Qatar|
RE|Indian/Reunion|
RO|Europe/Bucharest|
RS|Europe/Belgrade|
RU|Europe/Kaliningrad|MSK-01 - Kaliningrad
RU|Europe/Moscow|MSK+00 - Moscow area
UA|Europe/Simferopol|Crimea
RU|Europe/Kirov|MSK+00 - Kirov
RU|Europe/Volgograd|MSK+00 - Volgograd
RU|Europe/Astrakhan|MSK+01 - Astrakhan
RU|Europe/Saratov|MSK+01 - Saratov
RU|Europe/Ulyanovsk|MSK+01 - Ulyanovsk
RU|Europe/Samara|MSK+01 - Samara, Udmurtia
RU|Asia/Yekaterinburg|MSK+02 - Urals
RU|Asia/Omsk|MSK+03 - Omsk
RU|Asia/Novosibirsk|MSK+04 - Novosibirsk
RU|Asia/Barnaul|MSK+04 - Altai
RU|Asia/Tomsk|MSK+04 - Tomsk
RU|Asia/Novokuznetsk|MSK+04 - Kemerovo
RU|Asia/Krasnoyarsk|MSK+04 - Krasnoyarsk area
RU|Asia/Irkutsk|MSK+05 - Irkutsk, Buryatia
RU|Asia/Chita|MSK+06 - Zabaykalsky
RU|Asia/Yakutsk|MSK+06 - Lena River
RU|Asia/Khandyga|MSK+06 - Tomponsky, Ust-Maysky
RU|Asia/Vladivostok|MSK+07 - Amur River
RU|Asia/Ust-Nera|MSK+07 - Oymyakonsky
RU|Asia/Magadan|MSK+08 - Magadan
RU|Asia/Sakhalin|MSK+08 - Sakhalin Island
RU|Asia/Srednekolymsk|MSK+08 - Sakha (E), N Kuril Is
RU|Asia/Kamchatka|MSK+09 - Kamchatka
RU|Asia/Anadyr|MSK+09 - Bering Sea
RW|Africa/Kigali|
SA|Asia/Riyadh|
SB|Pacific/Guadalcanal|
SC|Indian/Mahe|
SD|Africa/Khartoum|
SE|Europe/Stockholm|
SG|Asia/Singapore|
SH|Atlantic/St_Helena|
SI|Europe/Ljubljana|
SJ|Arctic/Longyearbyen|
SK|Europe/Bratislava|
SL|Africa/Freetown|
SM|Europe/San_Marino|
SN|Africa/Dakar|
SO|Africa/Mogadishu|
SR|America/Paramaribo|
SS|Africa/Juba|
ST|Africa/Sao_Tome|
SV|America/El_Salvador|
SX|America/Lower_Princes|
SY|Asia/Damascus|
SZ|Africa/Mbabane|
TC|America/Grand_Turk|
TD|Africa/Ndjamena|
TF|Indian/Kerguelen|
TG|Africa/Lome|
TH|Asia/Bangkok|
TJ|Asia/Dushanbe|
TK|Pacific/Fakaofo|
TL|Asia/Dili|
TM|Asia/Ashgabat|
TN|Africa/Tunis|
TO|Pacific/Tongatapu|
TR|Europe/Istanbul|
TT|America/Port_of_Spain|
TV|Pacific/Funafuti|
TW|Asia/Taipei|
TZ|Africa/Dar_es_Salaam|
UA|Europe/Kyiv|most of Ukraine
UG|Africa/Kampala|
UM|Pacific/Midway|Midway Islands
UM|Pacific/Wake|Wake Island
US|America/New_York|Eastern (most areas)
US|America/Detroit|Eastern - MI (most areas)
US|America/Kentucky/Louisville|Eastern - KY (Louisville area)
US|America/Kentucky/Monticello|Eastern - KY (Wayne)
US|America/Indiana/Indianapolis|Eastern - IN (most areas)
US|America/Indiana/Vincennes|Eastern - IN (Da, Du, K, Mn)
US|America/Indiana/Winamac|Eastern - IN (Pulaski)
US|America/Indiana/Marengo|Eastern - IN (Crawford)
US|America/Indiana/Petersburg|Eastern - IN (Pike)
US|America/Indiana/Vevay|Eastern - IN (Switzerland)
US|America/Chicago|Central (most areas)
US|America/Indiana/Tell_City|Central - IN (Perry)
US|America/Indiana/Knox|Central - IN (Starke)
US|America/Menominee|Central - MI (Wisconsin border)
US|America/North_Dakota/Center|Central - ND (Oliver)
US|America/North_Dakota/New_Salem|Central - ND (Morton rural)
US|America/North_Dakota/Beulah|Central - ND (Mercer)
US|America/Denver|Mountain (most areas)
US|America/Boise|Mountain - ID (south), OR (east)
US|America/Phoenix|MST - AZ (except Navajo)
US|America/Los_Angeles|Pacific
US|America/Anchorage|Alaska (most areas)
US|America/Juneau|Alaska - Juneau area
US|America/Sitka|Alaska - Sitka area
US|America/Metlakatla|Alaska - Annette Island
US|America/Yakutat|Alaska - Yakutat
US|America/Nome|Alaska (west)
US|America/Adak|Alaska - western Aleutians
US|Pacific/Honolulu|Hawaii
UY|America/Montevideo|
UZ|Asia/Samarkand|Uzbekistan (west)
UZ|Asia/Tashkent|Uzbekistan (east)
VA|Europe/Vatican|
VC|America/St_Vincent|
VE|America/Caracas|
VG|America/Tortola|
VI|America/St_Thomas|
VN|Asia/Ho_Chi_Minh|
VU|Pacific/Efate|
WF|Pacific/Wallis|
WS|Pacific/Apia|
YE|Asia/Aden|
YT|Indian/Mayotte|
ZA|Africa/Johannesburg|
ZM|Africa/Lusaka|
ZW|Africa/Harare|`,xe=`Australia/ACT|Australia/Sydney
Australia/LHI|Australia/Lord_Howe
Australia/NSW|Australia/Sydney
Australia/North|Australia/Darwin
Australia/Queensland|Australia/Brisbane
Australia/South|Australia/Adelaide
Australia/Tasmania|Australia/Hobart
Australia/Victoria|Australia/Melbourne
Australia/West|Australia/Perth
Australia/Yancowinna|Australia/Broken_Hill
Brazil/Acre|America/Rio_Branco
Brazil/DeNoronha|America/Noronha
Brazil/East|America/Sao_Paulo
Brazil/West|America/Manaus
Canada/Atlantic|America/Halifax
Canada/Central|America/Winnipeg
Canada/Eastern|America/Toronto
Canada/Mountain|America/Edmonton
Canada/Newfoundland|America/St_Johns
Canada/Pacific|America/Vancouver
Canada/Saskatchewan|America/Regina
Canada/Yukon|America/Whitehorse
Chile/Continental|America/Santiago
Chile/EasterIsland|Pacific/Easter
Mexico/BajaNorte|America/Tijuana
Mexico/BajaSur|America/Mazatlan
Mexico/General|America/Mexico_City
US/Alaska|America/Anchorage
US/Aleutian|America/Adak
US/Arizona|America/Phoenix
US/Central|America/Chicago
US/East-Indiana|America/Indiana/Indianapolis
US/Eastern|America/New_York
US/Hawaii|Pacific/Honolulu
US/Indiana-Starke|America/Indiana/Knox
US/Michigan|America/Detroit
US/Mountain|America/Denver
US/Pacific|America/Los_Angeles
US/Samoa|Pacific/Pago_Pago
America/Buenos_Aires|America/Argentina/Buenos_Aires
America/Catamarca|America/Argentina/Catamarca
America/Cordoba|America/Argentina/Cordoba
America/Indianapolis|America/Indiana/Indianapolis
America/Jujuy|America/Argentina/Jujuy
America/Knox_IN|America/Indiana/Knox
America/Louisville|America/Kentucky/Louisville
America/Mendoza|America/Argentina/Mendoza
America/Virgin|America/Puerto_Rico
Pacific/Samoa|Pacific/Pago_Pago
Africa/Accra|Africa/Abidjan
Africa/Addis_Ababa|Africa/Nairobi
Africa/Asmara|Africa/Nairobi
Africa/Bamako|Africa/Abidjan
Africa/Bangui|Africa/Lagos
Africa/Banjul|Africa/Abidjan
Africa/Blantyre|Africa/Maputo
Africa/Brazzaville|Africa/Lagos
Africa/Bujumbura|Africa/Maputo
Africa/Conakry|Africa/Abidjan
Africa/Dakar|Africa/Abidjan
Africa/Dar_es_Salaam|Africa/Nairobi
Africa/Djibouti|Africa/Nairobi
Africa/Douala|Africa/Lagos
Africa/Freetown|Africa/Abidjan
Africa/Gaborone|Africa/Maputo
Africa/Harare|Africa/Maputo
Africa/Kampala|Africa/Nairobi
Africa/Kigali|Africa/Maputo
Africa/Kinshasa|Africa/Lagos
Africa/Libreville|Africa/Lagos
Africa/Lome|Africa/Abidjan
Africa/Luanda|Africa/Lagos
Africa/Lubumbashi|Africa/Maputo
Africa/Lusaka|Africa/Maputo
Africa/Malabo|Africa/Lagos
Africa/Maseru|Africa/Johannesburg
Africa/Mbabane|Africa/Johannesburg
Africa/Mogadishu|Africa/Nairobi
Africa/Niamey|Africa/Lagos
Africa/Nouakchott|Africa/Abidjan
Africa/Ouagadougou|Africa/Abidjan
Africa/Porto-Novo|Africa/Lagos
America/Anguilla|America/Puerto_Rico
America/Antigua|America/Puerto_Rico
America/Aruba|America/Puerto_Rico
America/Atikokan|America/Panama
America/Blanc-Sablon|America/Puerto_Rico
America/Cayman|America/Panama
America/Creston|America/Phoenix
America/Curacao|America/Puerto_Rico
America/Dominica|America/Puerto_Rico
America/Grenada|America/Puerto_Rico
America/Guadeloupe|America/Puerto_Rico
America/Kralendijk|America/Puerto_Rico
America/Lower_Princes|America/Puerto_Rico
America/Marigot|America/Puerto_Rico
America/Montserrat|America/Puerto_Rico
America/Nassau|America/Toronto
America/Port_of_Spain|America/Puerto_Rico
America/St_Barthelemy|America/Puerto_Rico
America/St_Kitts|America/Puerto_Rico
America/St_Lucia|America/Puerto_Rico
America/St_Thomas|America/Puerto_Rico
America/St_Vincent|America/Puerto_Rico
America/Tortola|America/Puerto_Rico
Antarctica/DumontDUrville|Pacific/Port_Moresby
Antarctica/McMurdo|Pacific/Auckland
Antarctica/Syowa|Asia/Riyadh
Arctic/Longyearbyen|Europe/Berlin
Asia/Aden|Asia/Riyadh
Asia/Bahrain|Asia/Qatar
Asia/Brunei|Asia/Kuching
Asia/Kuala_Lumpur|Asia/Singapore
Asia/Kuwait|Asia/Riyadh
Asia/Muscat|Asia/Dubai
Asia/Phnom_Penh|Asia/Bangkok
Asia/Vientiane|Asia/Bangkok
Atlantic/Reykjavik|Africa/Abidjan
Atlantic/St_Helena|Africa/Abidjan
Europe/Amsterdam|Europe/Brussels
Europe/Bratislava|Europe/Prague
Europe/Busingen|Europe/Zurich
Europe/Copenhagen|Europe/Berlin
Europe/Guernsey|Europe/London
Europe/Isle_of_Man|Europe/London
Europe/Jersey|Europe/London
Europe/Ljubljana|Europe/Belgrade
Europe/Luxembourg|Europe/Brussels
Europe/Mariehamn|Europe/Helsinki
Europe/Monaco|Europe/Paris
Europe/Oslo|Europe/Berlin
Europe/Podgorica|Europe/Belgrade
Europe/San_Marino|Europe/Rome
Europe/Sarajevo|Europe/Belgrade
Europe/Skopje|Europe/Belgrade
Europe/Stockholm|Europe/Berlin
Europe/Vaduz|Europe/Zurich
Europe/Vatican|Europe/Rome
Europe/Zagreb|Europe/Belgrade
Indian/Antananarivo|Africa/Nairobi
Indian/Christmas|Asia/Bangkok
Indian/Cocos|Asia/Yangon
Indian/Comoro|Africa/Nairobi
Indian/Kerguelen|Indian/Maldives
Indian/Mahe|Asia/Dubai
Indian/Mayotte|Africa/Nairobi
Indian/Reunion|Asia/Dubai
Pacific/Chuuk|Pacific/Port_Moresby
Pacific/Funafuti|Pacific/Tarawa
Pacific/Majuro|Pacific/Tarawa
Pacific/Midway|Pacific/Pago_Pago
Pacific/Pohnpei|Pacific/Guadalcanal
Pacific/Saipan|Pacific/Guam
Pacific/Wake|Pacific/Tarawa
Pacific/Wallis|Pacific/Tarawa
Africa/Timbuktu|Africa/Abidjan
America/Argentina/ComodRivadavia|America/Argentina/Catamarca
America/Atka|America/Adak
America/Coral_Harbour|America/Panama
America/Ensenada|America/Tijuana
America/Fort_Wayne|America/Indiana/Indianapolis
America/Montreal|America/Toronto
America/Nipigon|America/Toronto
America/Pangnirtung|America/Iqaluit
America/Porto_Acre|America/Rio_Branco
America/Rainy_River|America/Winnipeg
America/Rosario|America/Argentina/Cordoba
America/Santa_Isabel|America/Tijuana
America/Shiprock|America/Denver
America/Thunder_Bay|America/Toronto
America/Yellowknife|America/Edmonton
Antarctica/South_Pole|Pacific/Auckland
Asia/Choibalsan|Asia/Ulaanbaatar
Asia/Chongqing|Asia/Shanghai
Asia/Harbin|Asia/Shanghai
Asia/Kashgar|Asia/Urumqi
Asia/Tel_Aviv|Asia/Jerusalem
Atlantic/Jan_Mayen|Europe/Berlin
Australia/Canberra|Australia/Sydney
Australia/Currie|Australia/Hobart
Europe/Belfast|Europe/London
Europe/Tiraspol|Europe/Chisinau
Europe/Uzhgorod|Europe/Kyiv
Europe/Zaporozhye|Europe/Kyiv
Pacific/Enderbury|Pacific/Kanton
Pacific/Johnston|Pacific/Honolulu
Pacific/Yap|Pacific/Port_Moresby
Africa/Asmera|Africa/Nairobi
America/Godthab|America/Nuuk
Asia/Ashkhabad|Asia/Ashgabat
Asia/Calcutta|Asia/Kolkata
Asia/Chungking|Asia/Shanghai
Asia/Dacca|Asia/Dhaka
Asia/Istanbul|Europe/Istanbul
Asia/Katmandu|Asia/Kathmandu
Asia/Macao|Asia/Macau
Asia/Rangoon|Asia/Yangon
Asia/Saigon|Asia/Ho_Chi_Minh
Asia/Thimbu|Asia/Thimphu
Asia/Ujung_Pandang|Asia/Makassar
Asia/Ulan_Bator|Asia/Ulaanbaatar
Atlantic/Faeroe|Atlantic/Faroe
Europe/Kiev|Europe/Kyiv
Europe/Nicosia|Asia/Nicosia
Pacific/Ponape|Pacific/Guadalcanal
Pacific/Truk|Pacific/Port_Moresby`,Se=/* @__PURE__ */ `Pacific/Honolulu.America/Anchorage.America/Los_Angeles.America/Vancouver.America/Tijuana.America/Phoenix.America/Denver.America/Edmonton.America/Chicago.America/Mexico_City.America/Winnipeg.America/New_York.America/Toronto.America/Detroit.America/Panama.America/Bogota.America/Lima.America/Caracas.America/Halifax.America/Puerto_Rico.America/Santiago.America/St_Johns.America/Sao_Paulo.America/Recife.America/Argentina/Buenos_Aires.America/Montevideo.Atlantic/Azores.Atlantic/Reykjavik.Europe/London.Europe/Dublin.Europe/Lisbon.Africa/Casablanca.Africa/Lagos.Europe/Paris.Europe/Brussels.Europe/Amsterdam.Europe/Berlin.Europe/Zurich.Europe/Vienna.Europe/Rome.Europe/Madrid.Europe/Stockholm.Europe/Oslo.Europe/Copenhagen.Europe/Prague.Europe/Warsaw.Europe/Budapest.Europe/Belgrade.Africa/Johannesburg.Africa/Cairo.Europe/Athens.Europe/Bucharest.Europe/Helsinki.Europe/Kyiv.Asia/Jerusalem.Europe/Istanbul.Europe/Moscow.Africa/Nairobi.Asia/Riyadh.Asia/Baghdad.Asia/Tehran.Asia/Dubai.Asia/Baku.Asia/Kabul.Asia/Karachi.Asia/Tashkent.Asia/Kolkata.Asia/Colombo.Asia/Kathmandu.Asia/Dhaka.Asia/Almaty.Asia/Yangon.Asia/Bangkok.Asia/Ho_Chi_Minh.Asia/Jakarta.Asia/Singapore.Asia/Kuala_Lumpur.Asia/Manila.Asia/Shanghai.Asia/Hong_Kong.Asia/Taipei.Australia/Perth.Asia/Seoul.Asia/Tokyo.Australia/Darwin.Australia/Adelaide.Australia/Brisbane.Australia/Sydney.Australia/Melbourne.Australia/Hobart.Pacific/Guam.Pacific/Noumea.Pacific/Auckland.Pacific/Fiji.Pacific/Tongatapu.Pacific/Kiritimati.UTC`.split(`.`),Ce=/* @__PURE__ */ `-12:00.-11:00.-10:00.-09:30.-09:00.-08:00.-07:00.-06:00.-05:00.-04:00.-03:30.-03:00.-02:00.-01:00.+00:00.+01:00.+02:00.+03:00.+03:30.+04:00.+04:30.+05:00.+05:30.+05:45.+06:00.+06:30.+07:00.+08:00.+08:45.+09:00.+09:30.+10:00.+10:30.+11:00.+12:00.+12:45.+13:00.+14:00`.split(`.`),we=/^(?:UTC|GMT)?\s*([+-])(\d{1,2})(?::?(\d{2}))?$/i;function Te(e){var t=we.exec(e.trim());if(t){var n=Number(t[2]),r=Number(t[3]??0);if(!(n>14||r>59))return`${t[1]}${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}`}}function S(e){var t=Te(e);if(t)return(t[0]===`-`?-1:1)*(Number(t.slice(1,3))*60+Number(t.slice(4,6)))}var Ee=/* @__PURE__ */ new Map;function De(e){if(Ee.has(e))return Ee.get(e)??void 0;var t=null;try{t=new Intl.DateTimeFormat(`en-US`,{timeZone:e,year:`numeric`,month:`2-digit`,day:`2-digit`,hour:`2-digit`,minute:`2-digit`,hour12:!1})}catch{}return Ee.set(e,t),t??void 0}function C(e,t){var n=S(e);if(n!==void 0)return n;var r=De(e);if(r)try{var i=r.format(new Date(t)).match(/\d+/g);if(!i||i.length<5)return;var[a,o,s,c,l]=i.map(Number),u=Date.UTC(s,a-1,o,c%24,l),d=Math.floor(t/6e4)*6e4;return Math.round((u-d)/6e4)}catch{return}}var w;function Oe(){if(w!==void 0)return w;var e=Date.now();return w=C(`Asia/Tokyo`,e)===540&&C(`UTC`,e)===0,w}function ke(e){return S(e)!==void 0||Oe()&&C(e,Date.now())!==void 0}function Ae(e){if(e===0)return`UTC`;var t=e<0?`−`:`+`,n=Math.abs(e),r=n%60;return`UTC${t}${Math.floor(n/60)}${r?`:${String(r).padStart(2,`0`)}`:``}`}var je=[`Sun`,`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`];function Me(e,t,n){var r=String(t).padStart(2,`0`);return n?`${String(e).padStart(2,`0`)}:${r}`:`${e%12||12}:${r} ${e>=12?`PM`:`AM`}`}function T(e,t,n){if(Number.isFinite(t)&&(S(e)!==void 0||Oe())){var r=C(e,t);if(r!==void 0){var i=new Date(t+r*6e4),a=new Date(t),o=i.getUTCDay();return{time:Me(i.getUTCHours(),i.getUTCMinutes(),n),otherDay:o===a.getDay()?void 0:je[o],offset:Ae(r)}}}}function E(e){var t=S(e);return t===void 0?(e.split(`/`).pop()??e).replace(/_/g,` `):Ae(t)}function Ne(e){if(typeof e==`string`){var t=e.trim();if(t)return Te(t)??t}}var Pe={usa:`US`,us:`US`,america:`US`,"united states of america":`US`,uk:`GB`,"united kingdom":`GB`,"great britain":`GB`,britain:`GB`,england:`GB`,scotland:`GB`,wales:`GB`,"northern ireland":`GB`,uae:`AE`,emirates:`AE`,"united arab emirates":`AE`,"south korea":`KR`,korea:`KR`,"north korea":`KP`,holland:`NL`,czechia:`CZ`,turkiye:`TR`,burma:`MM`,"ivory coast":`CI`,drc:`CD`,"democratic republic of the congo":`CD`,"republic of the congo":`CG`,swaziland:`SZ`,macao:`MO`,"cape verde":`CV`,"east timor":`TL`,palestine:`PS`,vatican:`VA`,"american samoa":`AS`,samoa:`WS`,bosnia:`BA`,trinidad:`TT`},Fe=/* @__PURE__ */ RegExp(`[̀-ͯ]`,`g`);function D(e){var t=e.toLowerCase();try{t=t.normalize(`NFD`).replace(Fe,``)}catch{}return t.replace(/[_\-/().,'&]+/g,` `).replace(/\s+/g,` `).trim()}var O;function Ie(){if(O)return O;var e=[],t=/* @__PURE__ */ new Map;for(var n of be.split(`
`)){var[r,i,a=``]=n.split(`|`);if(i){var o=E(i),s={zone:i,cc:r,country:ye[r]??r,city:o,note:a,cityKey:D(o),pathKey:D(i),noteKey:D(a)};e.push(s);var c=t.get(r)??[];c.push(s),t.set(r,c)}}var l=[];for(var u of xe.split(`
`)){var[d,f]=u.split(`|`);d&&f&&l.push([D(d),d,f])}return O={zones:e,byCountry:t,links:l},O}function Le(e){var t=[],n=[],r=Pe[e];r&&t.push(r);for(var[i,a]of Object.entries(Pe))i!==e&&i.startsWith(e)&&e.length>=3&&!t.includes(a)&&t.push(a);for(var o of Object.keys(ye)){var s=D(ye[o]);t.includes(o)||(s===e||s.startsWith(e)?t.push(o):e.length>=3&&s.includes(e)&&n.push(o))}return[...t,...n]}function k(e){return{zone:e.zone,title:e.city,detail:e.note?`${e.country} · ${e.note}`:e.country,place:`${e.city}, ${e.country}`}}function Re(e){var t=ye[e]??e,n=Ie().byCountry.get(e)??[];return n.length===1?[{zone:n[0].zone,title:t,detail:n[0].city,place:t}]:n.map(function(e){return{zone:e.zone,title:`${t} — ${e.city}`,detail:e.note||void 0,place:`${e.city}, ${t}`}})}function A(e){var t=S(e);if(t!==void 0)return{zone:e,title:Ae(t),detail:`Fixed offset, no daylight saving`};var n=Ie().zones.find(function(t){return t.zone===e});return n?k(n):{zone:e,title:E(e)}}function ze(e,t=60){var n=D(e);if(!n)return Se.map(A).slice(0,t);var{zones:r,links:i}=Ie(),a=[],o=/* @__PURE__ */ new Set,s=function(e){o.has(e.zone)||(o.add(e.zone),a.push(e))},c=Te(e);c&&s(A(c)),(n===`utc`||n===`gmt`)&&s(A(`UTC`));for(var l of Le(n))for(var u of Re(l))s(u);for(var d of r)d.cityKey.startsWith(n)&&s(k(d));var f=new Set(r.map(function(e){return e.zone}));for(var[p,m,h]of i)f.has(m)||((p.split(` `).pop()??p).startsWith(n)||p===n)&&s({...A(h),detail:`Old name: ${m}`});if(n.length>=3){for(var g of r)(g.cityKey.includes(n)||g.pathKey.includes(n))&&s(k(g));for(var _ of r)_.noteKey.includes(n)&&s(k(_))}var v=e.trim();/^[A-Za-z]/.test(v)&&v.length>=3&&!o.has(v)&&ke(v)&&s({zone:v,title:v});var y=v.replace(/^(?:utc|gmt)\s*/i,``);if(/^[+-]\d/.test(y))for(var b of Ce)(b.startsWith(y)||b.replace(/^([+-])0/,`$1`).startsWith(y))&&s(A(b));return a.slice(0,t)}var Be=`[Timezones]`,Ve=`https://timezone.creations.works/list`,He=36e5,Ue=15e3,We=3e4,Ge=6e5,Ke=2e5,qe=/* @__PURE__ */ new Map,j=0,Je=!1,Ye=0,M=0,N=!0,Xe=/* @__PURE__ */ new Set;function Ze(){for(var e of Xe)try{e()}catch{}}function Qe(e){if(!N&&(Date.now()-j>He&&$e(),j))return qe.get(e)??null}async function $e(){if(!(Je||N||Date.now()<Ye)){Je=!0;var e=typeof AbortController==`function`?new AbortController:void 0,t=setTimeout(function(){return e?.abort()},Ue);try{var n=await fetch(Ve,{headers:{Accept:`application/json`},credentials:`omit`,signal:e?.signal});if(!n.ok)throw Error(`HTTP ${n.status}`);var r=await n.json();if(!r||typeof r!=`object`)throw Error(`not a list`);var i=/* @__PURE__ */ new Map;for(var a in r){if(i.size>=Ke)break;if(/^\d{15,21}$/.test(a)){var o=Ne(r[a]?.timezone);o&&i.set(a,o)}}if(N)return;qe=i,j=Date.now(),M=0,Ye=0,Ze()}catch(e){M||p(`${Be} Equicord timezone list failed:`,e),M=M?Math.min(M*2,Ge):We,Ye=Date.now()+M}finally{clearTimeout(t),Je=!1}}}function et(e){return Xe.add(e),function(){return Xe.delete(e)}}function tt(){N=!1,M=0,Ye=0}function nt(){N=!0,qe=/* @__PURE__ */ new Map,j=0,Xe.clear()}var rt=`[Timezones]`,it=`https://timezonedb.catvibers.me/api/user/bulk`,at=100,ot=300,st=36e5,ct=1e4,lt=3e4,ut=6e5,dt=/* @__PURE__ */ new Map,P=/* @__PURE__ */ new Set,ft=/* @__PURE__ */ new Set,pt=/* @__PURE__ */ new Set,F,I=!1,L=0,R=0;function mt(e){R=R?Math.min(R*2,ut):lt;var t=e&&e>0?Math.min(e,ut):R;L=Date.now()+t}function z(e){F===void 0&&(F=setTimeout(bt,Math.max(e,L-Date.now())))}function ht(e){var t=dt.get(e);if(t&&!(Date.now()-t.at>st))return t.zone??null}function gt(e){!I&&/^\d{15,21}$/.test(e)&&(ht(e)!==void 0||ft.has(e)||P.has(e)||(P.add(e),z(ot)))}function _t(e){dt.delete(e),gt(e)}function vt(e){return pt.add(e),function(){return pt.delete(e)}}function yt(){for(var e of pt)try{e()}catch{}}async function bt(){if(F=void 0,!I&&P.size){if(Date.now()<L)z(0);else{var e=[...P].slice(0,at);for(var t of e)P.delete(t),ft.add(t);P.size&&z(ot);var n=typeof AbortController==`function`?new AbortController:void 0,r=setTimeout(function(){return n?.abort()},ct);try{var i=await fetch(it,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e),signal:n?.signal});if(!i.ok){var a=Number(i.headers?.get?.(`Retry-After`));throw Object.assign(/* @__PURE__ */ Error(`HTTP ${i.status}`),{retryAfterMs:Number.isFinite(a)&&a>0?a*1e3:void 0})}var o=await i.json(),s=Date.now();for(var c of e){var l=o?.[c];dt.set(c,{zone:Ne(l?.timezone),at:s})}R=0,L=0,I||yt()}catch(t){if(R||p(`${rt} shared timezone lookup failed:`,t),mt(t?.retryAfterMs),!I){for(var u of e)P.add(u);z(0)}}finally{clearTimeout(r);for(var d of e)ft.delete(d)}}}}function xt(){I=!1,R=0,L=0}function St(){I=!0,F!==void 0&&clearTimeout(F),F=void 0,P.clear(),pt.clear()}var B={showInChat:!0,sharedLookup:!0,equicordLookup:!1,placeSearch:!0,hour24:!1,showDay:!0,messageMenu:!0,profileCard:!0,people:{},introDismissed:!1},V,Ct,H=!1,U={...B},wt=/* @__PURE__ */ new Set;function Tt(){for(var e of wt)try{e()}catch{}}function Et(e){var t={};if(!e||typeof e!=`object`)return t;for(var n of Object.keys(e)){var r=e[n];r&&typeof r.zone==`string`&&(t[n]=r)}return t}function Dt(e,t){var n={...e,...t??{}};return n.people=Et(t?.people&&typeof t.people==`object`?{...e.people,...t.people}:e.people),n}function Ot(e){if(!(e&&e===V)&&(Ct?.(),Ct=void 0,V=e,H=!1,U={...B},e)){var t=e.cache;t&&(U=Dt(B,t),H=!0),Ct=e.subscribe?.(function(e,t){U=Dt(t===0?U:B,e),H=!0,Tt()}),Promise.resolve(e.get?.()).then(function(e){e&&(U=Dt(B,e)),H=!0,Tt()}).catch(function(){})}}function kt(e){!V&&e&&Ot(e)}function W(){return U}function At(){var[,e]=valenced.react.React.useReducer(function(e){return e+1},0);return valenced.react.React.useEffect(function(){return Mt(e)},[]),U}function G(e){U={...Dt(U,e),...e.people?{people:Et(e.people)}:{}},Tt();try{var t=H?V?.set?.(U,!0):V?.set(e);Promise.resolve(t).catch(function(){})}catch{}}function jt(e,t,n,r){var i={...W().people};n?i[e]={zone:n,name:t,at:Date.now(),...r?{place:r}:{}}:delete i[e],G({people:i})}function Mt(e){return wt.add(e),function(){return wt.delete(e)}}function K(e){var t=W(),n=t.people[e];if(n?.zone)return{zone:n.zone,place:n.place,source:`you`};var r=t.sharedLookup?ht(e):null;if(r)return{zone:r,source:`shared`};var i=t.equicordLookup?Qe(e):null;if(i)return{zone:i,source:`equicord`};r===void 0&&gt(e)}var Nt=`[Timezones]`,Pt=` · `;function Ft(e){try{if(e==null)return;if(typeof e==`number`)return e;if(e instanceof Date)return e.getTime();if(typeof e==`string`)return Date.parse(e);if(typeof e.valueOf==`function`){var t=Number(e.valueOf());if(Number.isFinite(t))return t}}catch{}}function It(){try{return valenced.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id}catch{return}}function Lt(e,t){var n=W();if(n.showInChat&&t!==void 0&&e!==It()){var r=K(e);if(r){var i=T(r.zone,t,n.hour24);if(i)return`${Pt}${i.time}${n.showDay&&i.otherDay?` ${i.otherDay}`:``}`}}}function Rt(e,t){if(typeof e!=`string`||!e||e.endsWith(t))return e;var n=e.indexOf(Pt);return`${n>0?e.slice(0,n):e}${t}`}var zt=200,q=/* @__PURE__ */ new Map;function Bt(e,t){q.delete(e),q.set(e,t),q.size>zt&&q.delete(q.keys().next().value)}var J;function Vt(){J===void 0&&(J=setTimeout(function(){J=void 0;for(var[e,t]of[...q])try{if(Lt(t.authorId,t.at)===t.shown)continue;var n=e.indexOf(`:`);n>0&&ve(e.slice(0,n),e.slice(n+1))}catch(e){p(`${Nt} refresh failed:`,e)}},50))}function Ht(){var{getModules:e}=valenced.modules.finders,{withName:t}=valenced.modules.finders.filters,n=[],r,i=e(t(`RowManager`),function(e){try{if(typeof e?.prototype?.generate!=`function`){p(`${Nt} RowManager.prototype.generate not found`,/* @__PURE__ */ Error(`missing`));return}n.push(valenced.patcher.before(e.prototype,`generate`,function(e){return r=e?.[0],e})),n.push(valenced.patcher.after(e.prototype,`generate`,function(e){var t=r;r=void 0;try{if(t?.rowType!==1)return e;var n=t.message,i=n?.author?.id==null?void 0:String(n.author.id);if(!i||!n?.id||!n?.channel_id)return e;var a=Ft(n.timestamp),o=Lt(i,a);if(Bt(`${n.channel_id}:${n.id}`,{authorId:i,at:a,shown:o}),!o)return e;var s=e?.message;s&&s.state===`SENT`&&typeof s.timestamp==`string`&&(s.timestamp=Rt(s.timestamp,o)),typeof n.__customTimestamp==`string`&&(n.__customTimestamp=Rt(n.__customTimestamp,o))}catch(e){p(`${Nt} chat timestamp failed:`,e)}return e}))}catch(e){p(`${Nt} could not patch RowManager:`,e)}}),a=vt(function(){return Vt()}),o=et(function(){return Vt()}),s=Mt(function(){return Vt()});return function(){a(),o(),s(),i();for(var e of n.reverse())e();r=void 0,J!==void 0&&clearTimeout(J),J=void 0,q.clear()}}function Ut(e,t,n){if(t&&n){var r=function(e,i,a){if(!(!e||a>40)){if(Array.isArray(e))for(var o of e){var s=r(o,i,a+1);if(s)return s}else if(e.props){var c=i||e.type===t,l=e.props.children;return c&&(Array.isArray(l)?l:[l]).some(function(e){return e?.type===n})?e:r(l,c,a+1)}}};return r(e,!1,0)}}var Wt=`https://geocoding-api.open-meteo.com/v1/search`,Gt=8e3,Kt=10,qt=/* @__PURE__ */ new Map;async function Jt(e){var t=e.trim(),n=t.toLowerCase(),r=qt.get(n);if(r)return r;var i=typeof AbortController==`function`?new AbortController:void 0,a=setTimeout(function(){return i?.abort()},Gt);try{var o=function(e){if(typeof e?.timezone!=`string`||typeof e?.name!=`string`)return`continue`;var t=[e.admin1,e.country].filter(function(t){return typeof t==`string`&&t&&t!==e.name});u.push({zone:e.timezone,title:e.name,detail:t.join(`, `)||void 0,place:e.country&&e.country!==e.name?`${e.name}, ${e.country}`:e.name})},s=`${Wt}?name=${encodeURIComponent(t)}&count=${Kt}&language=en&format=json`,c=await fetch(s,{signal:i?.signal});if(!c.ok)throw Error(`HTTP ${c.status}`);var l=await c.json(),u=[];for(var d of Array.isArray(l?.results)?l.results:[])o(d);return qt.set(n,u),u}finally{clearTimeout(a)}}function Yt(e,t=`SharedToast`){try{var n=valenced.discord.actions.ToastActionCreators,r={text:e};if(typeof n.openMana==`function`){n.openMana(t,r);return}n.open(t,r)}catch{}}var Xt=`[Timezones]`,Zt=`TimezonesPicker`;function Qt(e){var t=T(e,Date.now(),W().hour24);return t?`${t.time}${t.otherDay?` ${t.otherDay}`:``} now · ${t.offset}`:`This phone can't show this zone`}var $t=450;function en(e){var[t,n]=valenced.react.React.useState(),r=e.trim(),i=W().placeSearch&&r.length>=2&&!/^[+-]?\d/.test(r)&&!r.includes(`/`);return valenced.react.React.useEffect(function(){if(i){var e=!0,t=setTimeout(function(){Jt(r).then(function(t){return e&&n({q:r,places:t,failed:!1})},function(){return e&&n({q:r,places:[],failed:!0})})},$t);return function(){e=!1,clearTimeout(t)}}},[r,i]),i?t?.q===r?{places:t.places,state:t.failed?`failed`:`done`}:{places:[],state:`loading`}:{places:[],state:`idle`}}function tn({current:e,onPick:n}){var{TextInput:r,TableRowGroup:i,TableRow:a}=valenced.discord.design.Design,{ScrollView:o,View:s}=valenced.react.ReactNative,[c,l]=valenced.react.React.useState(``),u=ze(c),d=en(c),f=d.places.filter(function(e){return!u.some(function(t){return t.zone===e.zone&&t.title===e.title})}),p=function(r,i){return/*#__PURE__*/ (0,t.jsx)(a,{label:r.zone===e?`${r.title} ✓`:r.title,subLabel:[r.detail,Qt(r.zone)].filter(Boolean).join(` · `),onPress:function(){return n(r)}},`${r.zone}|${r.title}|${i}`)},m=d.state===`loading`?`Searching places…`:d.state===`failed`?`Couldn't search places online.`:d.state===`done`&&f.length===0&&u.length===0?`No place by that name.`:void 0;return/*#__PURE__*/ (0,t.jsxs)(s,{style:{gap:12},children:[/*#__PURE__*/ (0,t.jsx)(r,{placeholder:`A country, city or town, or an offset like +5:30`,autoCapitalize:`none`,autoCorrect:!1,value:c,onChange:l}),/*#__PURE__*/ (0,t.jsx)(o,{style:{maxHeight:320},keyboardShouldPersistTaps:`handled`,nestedScrollEnabled:!0,children:/*#__PURE__*/ (0,t.jsxs)(s,{style:{gap:12},children:[u.length>0&&/*#__PURE__*/ (0,t.jsx)(i,{title:c.trim()?`Countries and zones`:void 0,children:u.map(p)}),(f.length>0||m)&&/*#__PURE__*/ (0,t.jsxs)(i,{title:`Places`,children:[f.map(p),m&&/*#__PURE__*/ (0,t.jsx)(a,{label:m})]}),u.length===0&&d.state===`idle`&&/*#__PURE__*/ (0,t.jsx)(i,{children:/*#__PURE__*/ (0,t.jsx)(a,{label:`No matching timezone`,subLabel:`Try their country, a big city near them, or an offset like -4.`})})]})})]})}function Y(e,n){var{AlertModal:r,AlertActionButton:i}=valenced.discord.design.Design,a=valenced.discord.actions.AlertActionCreators,o=W().people[e],s=o?.zone,c=K(e),l=function(t,r){a.dismissAlert(Zt);try{jt(e,n,t,r),Yt(t?`${n}: ${r??E(t)}`:`Timezone for ${n} cleared.`,`TimezonesSavedToast`)}catch(e){p(`${Xt} saving the timezone failed:`,e)}},u=s?`Set to ${o?.place?`${o.place} (${s})`:s}. Pick another, or clear it.`:c?`The shared list says ${c.zone}. Picking one here overrides it for you.`:`Their local time shows next to their messages. Only you see this.`;a.openAlert(Zt,/*#__PURE__*/ (0,t.jsx)(r,{title:`Timezone for ${n}`,content:u,extraContent:/*#__PURE__*/ (0,t.jsx)(tn,{current:s??c?.zone,onPick:function(e){return l(e.zone,e.place)}}),actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[s&&/*#__PURE__*/ (0,t.jsx)(i,{text:`Clear`,variant:`destructive`,onPress:function(){return l(void 0)}}),/*#__PURE__*/ (0,t.jsx)(i,{text:`Cancel`,variant:`secondary`,onPress:function(){return a.dismissAlert(Zt)}})]})}))}var nn=`[Timezones]`;function rn(e){return/message/i.test(e)&&!/channel|forum|guild|thread/i.test(e)}var an;function on(){if(!an){var{lookupModule:e}=valenced.modules.finders,{withProps:t}=valenced.modules.finders.filters;an=e(t(`ActionSheetRow`))?.[0]?.ActionSheetRow}return an}function sn(e){var t=/* @__PURE__ */ new Set,n,r=function(e,i){if(!(n||!e||i>30||t.has(e))){if(t.add(e),e.props?.message?.author)n=e.props.message;else if(Array.isArray(e))for(var a of e)r(a,i+1);else r(e.props?.children,i+1)}};return r(e,0),n}function cn(e){if(!W().messageMenu)return null;var n=on();if(!n)return null;var r=e?.author?.id==null?``:String(e.author.id);if(!r)return null;try{if(r===valenced.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id)return null}catch{}var i=e.author?.globalName??e.author?.username??`this person`,a=K(r),o=a&&T(a.zone,Date.now(),W().hour24),s=o?`Their time: ${o.time}${o.otherDay?` ${o.otherDay}`:``}`:`Set their timezone…`,c=a?`${a.place??E(a.zone)} · ${a.source===`you`?`set by you, tap to change`:a.source===`equicord`?`from Equicord's list, tap to set your own`:`from the shared list, tap to set your own`}`:`Show their local time next to their messages`,{getAssetIdByName:l}=valenced.assets;return/*#__PURE__*/ (0,t.jsx)(n.Group,{children:/*#__PURE__*/ (0,t.jsx)(n,{label:s,subLabel:c,icon:/*#__PURE__*/ (0,t.jsx)(n.Icon,{source:l(`ClockIcon`)}),onPress:function(){try{valenced.discord.actions.ActionSheetActionCreators.hideActionSheet()}catch{}Y(r,i)}})})}function ln(e,t){if(!t)return!1;var n=cn(t);if(!n)return!1;var{ActionSheet:r}=valenced.discord.design.Design,i=Ut(e,r,on()?.Group);if(!i)return!1;var a=i.props.children;return Array.isArray(a)?a.push(n):i.props.children=[a,n],!0}var un=/* @__PURE__ */ new WeakSet;function dn(e,t){if(!e||typeof e.default!=`function`||un.has(e))return e;var n;return t.push(valenced.patcher.before(e,`default`,function(e){return n=e?.[0]?.message,e})),t.push(valenced.patcher.after(e,`default`,function(e){try{e!=null&&ln(e,n?.author?n:sn(e))}catch(e){p(`${nn} sheet injection failed:`,e)}return n=void 0,e})),un.add(e),e}function fn(){var{ActionSheetActionCreators:e}=valenced.discord.actions,t=[];return t.push(valenced.patcher.before(e,`openLazy`,function(e){try{var[n,r]=e;typeof r==`string`&&rn(r)&&n&&typeof n.then==`function`&&(e[0]=n.then(function(e){return dn(e,t)}))}catch(e){p(`${nn} openLazy hook failed:`,e)}return e})),function(){for(var e of t)try{e()}catch{}}}function pn(e){if(e===void 0)throw ReferenceError(`this hasn't been initialised - super() hasn't been called`);return e}function mn(e,t,n){return t=yn(t),Sn(e,xn()?Reflect.construct(t,n||[],yn(e).constructor):t.apply(e,n))}function hn(e,t){if(!(e instanceof t))throw TypeError(`Cannot call a class as a function`)}function gn(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,`value`in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}function _n(e,t,n){return t&&gn(e.prototype,t),n&&gn(e,n),e}function vn(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function yn(e){return yn=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},yn(e)}function bn(e,t){if(typeof t!=`function`&&t!==null)throw TypeError(`Super expression must either be null or a function`);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,writable:!0,configurable:!0}}),t&&Cn(e,t)}function xn(){try{var e=!Boolean.prototype.valueOf.call(Reflect.construct(Boolean,[],function(){}))}catch{}return(xn=function(){return!!e})()}function Sn(e,t){return t&&(wn(t)===`object`||typeof t==`function`)?t:pn(e)}function Cn(e,t){return Cn=Object.setPrototypeOf||function(e,t){return e.__proto__=t,e},Cn(e,t)}function wn(e){"@swc/helpers - typeof";return e&&typeof Symbol<`u`&&e.constructor===Symbol?`symbol`:typeof e}var X=`[Timezones]`,Tn=`modules/user_profile/native/UserProfileConnections.tsx`,En=`modules/user_profile/native/UserProfileCard.tsx`,Dn=`UserProfileApplicationRoleConnectionsCard`,On=new Set([`react.memo`,`react.forward_ref`,`react.lazy`].map(function(e){return Symbol.for(e)}));function kn(e){return typeof e==`function`||!!e&&typeof e==`object`&&On.has(e.$$typeof)}var An;function jn(){if(An===void 0)try{var e=valenced.discord.utils.modules.finders.lookupModuleWithImportedPath(En)?.[0];An=kn(e?.default)?e.default:null}catch{An=null}return An}function Mn(e){try{var t=valenced.discord.flux.Stores.UserStore?.getUser?.(e);return t?.globalName||t?.username||W().people[e]?.name||`this person`}catch{return`this person`}}function Nn(e){try{return valenced.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id===e}catch{return!1}}var Pn={you:`set by you`,shared:`from the shared list`,equicord:`from Equicord's list`};function Fn({userId:e}){var[,n]=valenced.react.React.useReducer(function(e){return e+1},0);valenced.react.React.useEffect(function(){var e=[Mt(n),vt(n),et(n)],t,r=setTimeout(function(){n(),t=setInterval(n,6e4)},6e4-Date.now()%6e4);return function(){for(var n of e)n();clearTimeout(r),t&&clearInterval(t)}},[]);var r=W();if(!r.profileCard)return null;var i=K(e);if(!i)return null;var a=T(i.zone,Date.now(),r.hour24);if(!a)return null;var o=valenced.discord.design.Design,s=kn(o?.TableRowGroup)?o.TableRowGroup:void 0,c=kn(o?.TableRow)?o.TableRow:void 0,l=jn();if(!s||!c||!l)return null;var u=`${a.time}${r.showDay&&a.otherDay?` ${a.otherDay}`:``}`,d=`${i.place??E(i.zone)} · ${a.offset} · ${Pn[i.source]??``}`;return/*#__PURE__*/ (0,t.jsx)(l,{title:`Local time`,titleStyle:{marginBottom:8},children:/*#__PURE__*/ (0,t.jsx)(s,{hasIcons:!1,children:/*#__PURE__*/ (0,t.jsx)(c,{label:u,subLabel:d,arrow:!0,onPress:function(){return Y(e,Mn(e))}})})})}var In=/*#__PURE__*/ function(e){"use strict";bn(t,e);function t(){hn(this,t);var e=mn(this,t,arguments);return vn(e,`state`,{failed:!1}),e}return _n(t,[{key:`componentDidCatch`,value:function(e){p(`${X} profile card failed:`,e)}},{key:`render`,value:function(){return this.state.failed?null:this.props.children}}],[{key:`getDerivedStateFromError`,value:function(){return{failed:!0}}}]),t}(valenced.react.React.Component);function Ln(){var e=[],n,r,i=function(r){try{if(typeof r?.[Dn]!=`function`){p(`${X} ${Dn} not found on ${Tn}; no time card on profiles.`);return}e.push(valenced.patcher.before(r,Dn,function(e){return n=e?.[0],e}),valenced.patcher.after(r,Dn,function(e){var r=n;n=void 0;var i=r?.userId;if(typeof i!=`string`||Nn(i))return e;try{var a=/*#__PURE__*/ (0,t.jsx)(In,{children:/*#__PURE__*/ (0,t.jsx)(Fn,{userId:i})},`timezones-card`);return e?/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[e,a]}):a}catch(t){return p(`${X} profile card render failed:`,t),e}}))}catch(e){p(`${X} failed to hook the profile:`,e)}};try{r=valenced.discord.utils.modules.finders.getModuleWithImportedPath(Tn,i)}catch(e){p(`${X} profile lookup failed:`,e)}return function(){r?.();for(var t of e)t();e.length=0}}var Rn=`[Timezones]`,Z,zn=/* @__PURE__ */ new WeakMap;function Bn(e){var t=zn.get(e);return t||(t=function(t){var n=Z;Z=t?.user?.id?{user:t.user,isSelf:t.user.id===t.currentUser?.id}:void 0;try{return e(t)}finally{Z=n}},zn.set(e,t)),t}function Vn(e){var t=K(e.id),n=t&&T(t.zone,Date.now(),W().hour24);return{label:n?`Their time: ${n.time}${n.otherDay?` ${n.otherDay}`:``}`:`Set timezone`,action:function(){return Y(e.id,e.globalName??e.username??`this person`)}}}function Hn(e){var t=e;try{var n=t[0];if(typeof n!=`function`)return e;if(n.name===`UserProfileOverflowMenu`)return t[0]=Bn(n),e;if(n.name!==`ContextMenu`||!Z||Z.isSelf)return e;var r=t[1],i=r?.items;if(!Array.isArray(i)||!Array.isArray(i[0]))return e;t[1]={...r,items:[[...i[0],Vn(Z.user)],...i.slice(1)]}}catch(e){p(`${Rn} profile menu failed:`,e)}return e}function Un(){var e=[valenced.patcher.before(valenced.react.ReactJSXRuntime,`jsx`,Hn),valenced.patcher.before(valenced.react.ReactJSXRuntime,`jsxs`,Hn)];return function(){for(var t of e)t();Z=void 0}}function Wn({author:e}={}){var{Text:n}=valenced.discord.design.Design,{View:r}=valenced.react.ReactNative;return/*#__PURE__*/ (0,t.jsxs)(r,{style:{alignItems:`center`,gap:2,opacity:.8},children:[/*#__PURE__*/ (0,t.jsxs)(n,{color:`text-muted`,variant:`text-sm/semibold`,style:{textAlign:`center`},children:[`Made by `,e??`bleelblep`]}),e?/*#__PURE__*/ (0,t.jsx)(n,{color:`text-muted`,variant:`text-xxs/normal`,style:{textAlign:`center`},children:`Ported by bleelblep`}):null]})}function Gn(e){Kn(e,`destructive`)}function Kn(e,n){var{AlertModal:r,AlertActionButton:i}=valenced.discord.design.Design,a=valenced.discord.actions.AlertActionCreators,o=`bleelblep-confirm-${Date.now()}`;a.openAlert(o,/*#__PURE__*/ (0,t.jsx)(r,{title:e.title,content:e.body,actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(i,{text:e.action,variant:n,onPress:function(){a.dismissAlert(o),e.onConfirm()}}),/*#__PURE__*/ (0,t.jsx)(i,{text:`Cancel`,variant:`secondary`,onPress:function(){return a.dismissAlert(o)}})]})}))}function qn(){try{var e=valenced.discord.design.Design;return e?.TableRow?e:void 0}catch{return}}function Jn({label:e,description:n,children:r}){var{View:i,Text:a}=valenced.react.ReactNative;return/*#__PURE__*/ (0,t.jsxs)(i,{style:{gap:8,paddingHorizontal:16,paddingVertical:12},children:[/*#__PURE__*/ (0,t.jsx)(a,{style:{fontSize:16,fontWeight:`600`,color:`#9a9aa2`},children:e}),r,n?/*#__PURE__*/ (0,t.jsx)(a,{style:{fontSize:12,color:`#9a9aa2`,opacity:.8},children:n}):null]})}function Yn({label:e,description:n,children:r}){var{View:i}=valenced.react.ReactNative,a=qn();if(!a)return/*#__PURE__*/ (0,t.jsx)(Jn,{label:e,description:n,children:r});var{TableRow:o,Text:s}=a;return/*#__PURE__*/ (0,t.jsx)(o,{label:e,subLabel:/*#__PURE__*/ (0,t.jsxs)(i,{style:{gap:8,marginTop:8},children:[r,n?/*#__PURE__*/ (0,t.jsx)(s,{variant:`text-sm/normal`,color:`text-muted`,children:n}):null]})})}function Xn({title:e,...n}){var r=qn()?.TableRowGroup;if(!r){var{View:i}=valenced.react.ReactNative;return/*#__PURE__*/ (0,t.jsx)(i,{children:/*#__PURE__*/ (0,t.jsx)(Yn,{...n})})}return/*#__PURE__*/ (0,t.jsx)(r,{title:e,children:/*#__PURE__*/ (0,t.jsx)(Yn,{...n})})}function Q(e,t){try{var n=valenced.discord.flux.Stores.UserStore?.getUser?.(e),r=n?.globalName??n?.global_name??n?.username;if(r)return r}catch{}return t||`User ${e}`}function Zn(e,t,n){var r=n??e,i=T(e,Date.now(),t);return i?`${i.time}${i.otherDay?` ${i.otherDay}`:``} · ${r}`:`${r} · can't be shown here`}function Qn(){var e=At(),{TableRowGroup:n,TableRow:r}=valenced.discord.design.Design,[,a]=valenced.react.React.useReducer(function(e){return e+1},0);valenced.react.React.useEffect(function(){var e=setInterval(a,6e4);return function(){return clearInterval(e)}},[]);var o=Object.entries(e.people).filter(function(e){return!!e[1]}).sort(function(e,t){return Q(e[0],e[1].name).localeCompare(Q(t[0],t[1].name))});return/*#__PURE__*/ (0,t.jsx)(t.Fragment,{children:/*#__PURE__*/ (0,t.jsx)(n,{title:`Timezones you set (${o.length})`,hasIcons:!0,children:o.length===0?/*#__PURE__*/ (0,t.jsx)(r,{label:`No one yet`,subLabel:`Long-press someone's message and choose Set their timezone, or add them by user ID below.`,icon:i(`UserCircleIcon`,`CompassIcon`)}):o.map(function([n,a]){return/*#__PURE__*/ (0,t.jsx)(r,{label:Q(n,a.name),subLabel:Zn(a.zone,e.hour24,a.place),icon:i(`UserCircleIcon`,`CompassIcon`),arrow:!0,onPress:function(){return $n(n,Q(n,a.name),e.sharedLookup)}},n)})})})}function $n(e,n,r){var{AlertModal:i,AlertActionButton:a}=valenced.discord.design.Design,o=valenced.discord.actions.AlertActionCreators,s=`timezones-person-${Date.now()}`;o.openAlert(s,/*#__PURE__*/ (0,t.jsx)(i,{title:n,actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(a,{text:`Change timezone`,variant:`primary`,onPress:function(){o.dismissAlert(s),Y(e,n)}}),/*#__PURE__*/ (0,t.jsx)(a,{text:`Remove`,variant:`destructive`,onPress:function(){o.dismissAlert(s),Gn({title:`Remove ${n}?`,body:r?`Their local time stops showing next to their messages, unless the shared list has them.`:`Their local time stops showing next to their messages.`,action:`Remove`,onConfirm:function(){return jt(e,n,void 0)}})}}),/*#__PURE__*/ (0,t.jsx)(a,{text:`Cancel`,variant:`secondary`,onPress:function(){return o.dismissAlert(s)}})]})}))}function er(){var{AlertModal:e,AlertActionButton:n}=valenced.discord.design.Design,r=valenced.discord.actions.AlertActionCreators,i=`timezones-hide-intro-${Date.now()}`;r.openAlert(i,/*#__PURE__*/ (0,t.jsx)(e,{title:`Hide this note?`,content:`It won't be shown again, even after updates.`,actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(n,{text:`Hide`,variant:`primary`,onPress:function(){r.dismissAlert(i),G({introDismissed:!0})}}),/*#__PURE__*/ (0,t.jsx)(n,{text:`Cancel`,variant:`secondary`,onPress:function(){return r.dismissAlert(i)}})]})}))}function tr(){var e=At(),{TableRowGroup:n,TableRow:r,TextInput:a}=valenced.discord.design.Design,[o,s]=valenced.react.React.useState(``),c=o.trim(),l=/^\d{15,21}$/.test(c);return/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(Xn,{label:`Add by user ID`,description:`Developer Mode lets you copy anyone's ID from their profile.`,children:/*#__PURE__*/ (0,t.jsx)(a,{placeholder:`123456789012345678`,value:o,onChange:s,keyboardType:`number-pad`})}),/*#__PURE__*/ (0,t.jsxs)(n,{hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(r,{label:`Choose their timezone`,icon:i(`ClockIcon`,`PlusSmallIcon`),arrow:!0,disabled:!l,onPress:function(){Y(c,Q(c)),s(``)}}),e.sharedLookup&&/*#__PURE__*/ (0,t.jsx)(r,{label:`Look them up again`,subLabel:`Ask the shared list about this ID now.`,icon:i(`RefreshIcon`,`ArrowAngleLeftUpIcon`),disabled:!l,onPress:function(){_t(c),Yt(`Looking them up…`,`TimezonesRefetchToast`)}})]})]})}function nr({api:e}){kt(e?.jsonStorage),re();var n=At(),{Page:r}=valenced.components,{ScrollView:a,View:o}=valenced.react.ReactNative,{Stack:c,Card:l,Button:u,Text:d,TableRowGroup:f,TableSwitchRow:p}=valenced.discord.design.Design;return/*#__PURE__*/ (0,t.jsx)(r,{children:/*#__PURE__*/ (0,t.jsx)(a,{contentContainerStyle:{paddingBottom:s()},children:/*#__PURE__*/ (0,t.jsxs)(c,{spacing:24,children:[n.introDismissed?null:/*#__PURE__*/ (0,t.jsx)(l,{variant:`secondary`,border:`none`,children:/*#__PURE__*/ (0,t.jsxs)(o,{style:{paddingHorizontal:16,paddingVertical:12},children:[/*#__PURE__*/ (0,t.jsx)(d,{color:`text-default`,variant:`text-md/semibold`,children:`Their time, beside their messages`}),/*#__PURE__*/ (0,t.jsx)(d,{color:`text-muted`,variant:`text-sm/normal`,style:{marginTop:8},children:`Long-press someone's message to set their timezone. Only you see it.`}),/*#__PURE__*/ (0,t.jsx)(o,{style:{marginTop:12,alignItems:`flex-start`},children:/*#__PURE__*/ (0,t.jsx)(u,{text:`Don't show again`,size:`sm`,variant:`secondary`,onPress:er})})]})}),/*#__PURE__*/ (0,t.jsx)(d,{color:`text-muted`,variant:`text-sm/normal`,children:`Timezones you set are only seen by you.`}),!Oe()&&/*#__PURE__*/ (0,t.jsx)(d,{color:`text-feedback-critical`,variant:`text-sm/normal`,children:`This Discord build can't work out city timezones, so only offsets like +5:30 show.`}),/*#__PURE__*/ (0,t.jsx)(Qn,{}),/*#__PURE__*/ (0,t.jsx)(tr,{}),/*#__PURE__*/ (0,t.jsxs)(f,{title:`Chat`,hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(p,{label:`Show in chat`,subLabel:`Their local time after the timestamp on their messages.`,icon:i(`ClockIcon`,`ic_clock`),value:n.showInChat,onValueChange:function(e){return G({showInChat:e})}}),/*#__PURE__*/ (0,t.jsx)(p,{label:`24-hour time`,subLabel:n.hour24?`15:02`:`3:02 PM`,icon:i(`TimerIcon`,`ClockIcon`),value:n.hour24,onValueChange:function(e){return G({hour24:e})}}),/*#__PURE__*/ (0,t.jsx)(p,{label:`Show their day`,subLabel:`Add the weekday when it's a different day for them, like 3:02 AM Tue.`,icon:i(`CalendarIcon`,`ClockIcon`),value:n.showDay,onValueChange:function(e){return G({showDay:e})}}),/*#__PURE__*/ (0,t.jsx)(p,{label:`Show in message menu`,subLabel:`The timezone row when you long-press a message. The ⋯ menu on their profile always has it.`,icon:i(`ChatIcon`,`ClockIcon`),value:n.messageMenu,onValueChange:function(e){return G({messageMenu:e})}}),/*#__PURE__*/ (0,t.jsx)(p,{label:`Show on their profile`,subLabel:`A Local time card on their profile, once their timezone is known. Tap it to change their timezone.`,icon:i(`UserCircleIcon`,`ClockIcon`),value:n.profileCard,onValueChange:function(e){return G({profileCard:e})}})]}),/*#__PURE__*/ (0,t.jsxs)(f,{title:`Lookups`,hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(p,{label:`Use the shared timezone list`,subLabel:`For people you haven't set, ask timezonedb.catvibers.me, where people add their own timezone. Sends it the IDs of people whose messages you see.`,icon:i(`GlobeEarthIcon`,`ic_link`),value:n.sharedLookup,onValueChange:function(e){return G({sharedLookup:e})}}),/*#__PURE__*/ (0,t.jsx)(p,{label:`Also use Equicord's list`,subLabel:`For people still without one, read the timezones people set in Equicord (timezone.creations.works). Downloads the whole list about once an hour; sends nothing about you. Read only: set yours from Equicord on desktop.`,icon:i(`GlobeEarthIcon`,`ic_link`),value:n.equicordLookup,onValueChange:function(e){return G({equicordLookup:e})}}),/*#__PURE__*/ (0,t.jsx)(p,{label:`Search places online`,subLabel:`Find any town or city when picking a timezone, through Open-Meteo. Sends only what you type. Countries and big cities work without it.`,icon:i(`MagnifyingGlassIcon`,`CompassIcon`),value:n.placeSearch,onValueChange:function(e){return G({placeSearch:e})}})]}),/*#__PURE__*/ (0,t.jsx)(Wn,{author:`aniimalz`})]})})})}var rr=`[Timezones]`;function $(e,t,n){try{e(n())}catch(e){p(`${rr} ${t} failed:`,e)}}return e.default=plugin({jsonStorage:{load:!0,default:B},start(e){if(f(e.plugin),e.cleanup(function(){return f(void 0)}),e.plugin.startedLate)e.plugin.requireReload();else{var{cleanup:t,jsonStorage:n}=e;Ot(n),t(function(){return Ot(void 0)}),xt(),t(St),tt(),t(nt),$(t,`changelog`,function(){return te(e,de)}),$(t,`message cache`,_e),$(t,`chat timestamp`,Ht),$(t,`message sheet`,fn),$(t,`profile menu`,Un),$(t,`profile card`,Ln)}},stop(e){St(),nt(),e.plugin.requireReload()},SettingsComponent:nr}),e})({},valenced.react.ReactJSXRuntime);