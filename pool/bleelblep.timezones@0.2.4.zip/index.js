(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});function n(e){"@swc/helpers - typeof";return e&&typeof Symbol<`u`&&e.constructor===Symbol?`symbol`:typeof e}var r={SparklesIcon:[`MagicWandIcon`],SparkleIcon:[`MagicWandIcon`]};function i(...e){return s(e,!1)}function a(...e){return s(e,!0)}function o(e){try{return e()}catch{return}}function s(e,i){var a=function(e){var n=o(function(){return c(e)||void 0}),r=o(function(){return f?.(e)});if(i)return d&&(r||n)?{v:/*#__PURE__*/ (0,t.jsx)(d,{source:n,IconComponent:r,variant:`danger`})}:`continue`;if(n&&d)return{v:/*#__PURE__*/ (0,t.jsx)(d,{source:n})};if(r)return{v:/*#__PURE__*/ (0,t.jsx)(r,{})}},s=[...new Set(e.flatMap(function(e){return[e,...r[e]??[]]}))],{getAssetIdByName:c}=valenced.assets,{TableRow:l,TableRowIcon:u}=valenced.discord.design.Design,d=l?.Icon??u,f=o(function(){return valenced.utils.discord.lookupGeneratedIconComponent});for(var p of s){var m=a(p);if(n(m)===`object`)return m.v}}function c(e=16){try{var t=valenced.externals.ReactNativeSafeAreaContext?.useSafeAreaInsets?.();if(typeof t?.bottom==`number`)return t.bottom+e}catch{}return e}var l=20,u,d=[],f=/* @__PURE__ */ new Set;function p(e){if(u=e,e)for(var t of d.splice(0))h(t)}function m(e,t){var n=g(e,t),r=n instanceof Error?n.message:String(n);f.has(r)||(f.add(r),u?h(n):d.length<l&&d.push(n))}function h(e){try{u?.reportError(e)}catch{}}function g(e,t){if(t===void 0)return Error(e);if(!e)return t;var n=t instanceof Error?t.message:String(t),r=/* @__PURE__ */ Error(`${e} ${n}`);if(t instanceof Error&&typeof t.stack==`string`){var i=t.stack.split(`
`).slice(1).join(`
`);i&&(r.stack=`${r.name}: ${r.message}\n${i}`)}return r}var _,v=`changelogSeenVersion`,y=3,b=function(e){return`${e}.changelog`};function ee(e){return typeof e==`string`?e:e&&Array.isArray(e.nums)?e.nums.join(`.`)+(e.label?`-${e.label}`:``):String(e??``)}function te(e){var[t,n]=String(e).split(`-`,2);return{nums:t.split(`.`).map(function(e){return Number.parseInt(e,10)||0}),pre:n}}function x(e,t){for(var n=te(e),r=te(t),i=0;i<Math.max(n.nums.length,r.nums.length);i++){var a=(n.nums[i]??0)-(r.nums[i]??0);if(a)return a}return n.pre===r.pre?0:n.pre===void 0?1:r.pre===void 0?-1:n.pre.localeCompare(r.pre,void 0,{numeric:!0})}function ne(e,t,n={}){var r=e.plugin.manifest,i={id:r.id,name:r.name??r.id,current:ee(r.version),entries:[...t].sort(function(e,t){return x(t.version,e.version)}),storage:e.jsonStorage,latestOnly:n.latestOnly};_=i;var a=ue(i);return re(i).catch(function(e){return m(`[${i.name}] changelog check failed:`,e)}),function(){_===i&&(_=void 0),a()}}async function re(e){if(e.storage){var t=await e.storage.get(),n=t?.[v]?ee(t[v]):void 0;if(n!==e.current){if(!n||x(e.current,n)<0)await e.storage.set({[v]:e.current});else{var r=e.entries.filter(function(t){return x(t.version,n)>0&&x(t.version,e.current)<=0});r.length?e.pending=e.latestOnly?r.slice(0,1):r:await e.storage.set({[v]:e.current})}}}}function ie(e={}){var{React:n}=valenced.react,{useNavigation:r}=valenced.externals.ReactNavigation.ReactNavigationNative,i=r(),a=e.header!==!1;n.useLayoutEffect(function(){a&&_&&i.setOptions?.({headerRight:function(){return/*#__PURE__*/ (0,t.jsx)(ae,{})}})},[a]),n.useEffect(function(){var e=_;if(e?.pending?.length){var t=e.pending;e.pending=void 0,ce(e,t,function(){return i.navigate(b(e.id))}),e.storage?.set({[v]:e.current}).catch(function(t){return m(`[${e.name}] could not save the seen version:`,t)})}},[])}function ae(){var{Pressable:e}=valenced.react.ReactNative,{useNavigation:n}=valenced.externals.ReactNavigation.ReactNavigationNative,r=n(),a=_;return a?/*#__PURE__*/ (0,t.jsx)(e,{accessibilityRole:`button`,accessibilityLabel:`Changelog`,hitSlop:12,onPress:function(){return r.navigate(b(a.id))},style:function({pressed:e}){return{paddingHorizontal:12,opacity:e?.5:1}},children:i(`ClockIcon`,`ic_clock`)}):null}function oe({changes:e}){var{View:n}=valenced.react.ReactNative,{Text:r}=valenced.discord.design.Design;return/*#__PURE__*/ (0,t.jsx)(n,{style:{gap:4},children:e.map(function(e,i){return/*#__PURE__*/ (0,t.jsxs)(n,{style:{flexDirection:`row`},children:[/*#__PURE__*/ (0,t.jsx)(r,{variant:`text-sm/normal`,color:`text-muted`,style:{width:14},children:`•`}),/*#__PURE__*/ (0,t.jsx)(r,{variant:`text-sm/normal`,color:`text-muted`,style:{flex:1},children:e})]},i)})})}function se(e){return e.title?`${e.version} · ${e.title}`:e.version}function ce(e,n,r){var{ScrollView:i,View:a,Dimensions:o}=valenced.react.ReactNative,{AlertModal:s,AlertActionButton:c,Text:l}=valenced.discord.design.Design,u=valenced.discord.actions.AlertActionCreators,d=`bleelblep-whats-new-${e.id}`,f=function(){return u.dismissAlert(d)},p=n.slice(0,y),h=n.length-p.length,g=/*#__PURE__*/ (0,t.jsx)(i,{style:{maxHeight:Math.round(o.get(`window`).height*.5)},nestedScrollEnabled:!0,children:/*#__PURE__*/ (0,t.jsxs)(a,{style:{gap:12},children:[p.map(function(e){return/*#__PURE__*/ (0,t.jsxs)(a,{style:{gap:4},children:[/*#__PURE__*/ (0,t.jsx)(l,{variant:`text-sm/semibold`,color:`text-default`,children:se(e)}),/*#__PURE__*/ (0,t.jsx)(oe,{changes:e.changes})]},e.version)}),h>0?/*#__PURE__*/ (0,t.jsxs)(l,{variant:`text-sm/normal`,color:`text-muted`,children:[`And `,h,` more version`,h===1?``:`s`,` in the full changelog.`]}):null]})});try{u.openAlert(d,/*#__PURE__*/ (0,t.jsx)(s,{title:`What's new in ${e.name} ${e.current}`,extraContent:g,actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(c,{text:`Full changelog`,variant:`primary`,onPress:function(){f(),r()}}),/*#__PURE__*/ (0,t.jsx)(c,{text:`Close`,variant:`secondary`,onPress:f})]})}))}catch(t){m(`[${e.name}] couldn't show what's new:`,t)}}function le(){var e=valenced.discord.modules.settings;typeof e.refreshSettings==`function`?e.refreshSettings():(e.refreshSettingsNavigator?.(),e.refreshSettingsOverviewScreen?.())}function ue(e){var{registerSettingsItem:t,onSettingsModulesLoaded:n}=valenced.discord.modules.settings,r=b(e.id),i,a=n(function(){i=t(r,{parent:null,type:`route`,useTitle:function(){return`Changelog`},screen:{route:r,getComponent:function(){return de}}}),le()});return function(){a(),i?.(),i=void 0,le()}}function de(){var{Page:e}=valenced.components,{ScrollView:n,View:r}=valenced.react.ReactNative,{Stack:i,Text:a,TableRowGroup:o,TableRow:s}=valenced.discord.design.Design,l=c(),u=_;return u?/*#__PURE__*/ (0,t.jsx)(e,{children:/*#__PURE__*/ (0,t.jsx)(n,{contentContainerStyle:{paddingBottom:l},children:/*#__PURE__*/ (0,t.jsxs)(i,{spacing:24,children:[/*#__PURE__*/ (0,t.jsxs)(a,{color:`text-muted`,variant:`text-sm/normal`,children:[`Every version of `,u.name,`, newest first. You have `,u.current,`.`]}),u.entries.map(function(e){var n=e.version===u.current?` · installed`:``;return/*#__PURE__*/ (0,t.jsx)(o,{title:`${e.version}${n}${e.date?` · ${e.date}`:``}`,children:/*#__PURE__*/ (0,t.jsx)(s,{label:e.title??`Version ${e.version}`,subLabel:/*#__PURE__*/ (0,t.jsx)(r,{style:{marginTop:6},children:/*#__PURE__*/ (0,t.jsx)(oe,{changes:e.changes})})})},e.version)})]})})}):null}var fe=[{version:`0.2.4`,date:`2026-10-28`,title:`Equicord's list`,changes:[`New switch, "Also use Equicord's list" (off by default): shows the timezones people set in Equicord, for anyone without one from you or the shared list. Read only.`]},{version:`0.2.3`,date:`2026-10-28`,title:`Quieter when offline`,changes:[`When the shared timezone list can't be reached, it waits before asking again (30 seconds, up to 10 minutes) instead of asking constantly, and shows one error instead of many.`]},{version:`0.2.2`,date:`2026-10-28`,title:`Bazinga Plugins`,changes:[`Now published from the Bazinga Plugins repository.`]},{version:`0.2.1`,date:`2026-10-26`,title:`Valenced`,changes:[`Ported to Valenced. Settings from Revenge don't carry over.`]},{version:`0.2.0`,date:`2026-10-25`,title:`Search any country or city`,changes:[`Type a country (Kenya, UK, New Zealand) to get its timezones, even offline.`,`Every timezone is searchable now, by city, region (Indiana) or old name (Calcutta).`,`Any town or city works too, found online through Open-Meteo. Turn it off under Lookups.`,`The place you pick is saved and shown, like "Mombasa, Kenya".`]},{version:`0.1.3`,date:`2026-10-23`,title:`Discord version limit removed`,changes:[`Installs on any Discord version again.`]},{version:`0.1.2`,date:`2026-10-22`,title:`Discord 352.2`,changes:[`Also starts on Discord 352.2 (was 351.6 or older).`]},{version:`0.1.1`,date:`2026-10-21`,title:`Discord version limit`,changes:[`Only starts on Discord 351.6 or older, so a newer Discord build can't break it.`]},{version:`0.1.0`,date:`2026-10-15`,title:`First version`,changes:[`Set someone's timezone from the message long-press menu or settings.`,`Their local time shows after the timestamp on their messages, with their weekday when it differs.`,`People you haven't set can come from the shared timezone list, which you can turn off.`]}];function pe(e,t,n,r=`[modules]`){var i=!1,a=[],o=function(){for(var e of a.splice(0))try{e()}catch{}},s=function(t,a){if(!i&&t){i=!0,Promise.resolve().then(o);try{n(t)}catch(t){m(`${r} patching ${e} failed:`,t)}}};try{var c=valenced.discord.utils.modules.finders;a.push(c.getModuleWithImportedPath(e,function(e){return s(e,`path`)}))}catch(t){m(`${r} path lookup for ${e} failed:`,t)}if(!i&&t)try{a.push(valenced.modules.finders.getModules(t,function(e){return s(e,`name`)},{returnNamespace:!0}))}catch(t){m(`${r} name lookup for ${e} failed:`,t)}return function(){i=!0,o()}}var me=`[Timezones]`,he=`​`,ge,_e=!1;function ve(){var{withProps:e}=valenced.modules.finders.filters,t=function(e){if(e){if(typeof e?.getOrCreate==`function`&&typeof e?.commit==`function`)return e;if(typeof e?.default?.getOrCreate==`function`&&typeof e?.default?.commit==`function`)return e.default;if(typeof e?._channelMessages?.getOrCreate==`function`&&typeof e?._channelMessages?.commit==`function`)return e._channelMessages}};return pe(`lib/ChannelMessages.tsx`,e(`getOrCreate`,`commit`),function(e){var n=t(e);n&&(ge=n)},me)}function ye(e,t){try{var n=ge;if(!n)return!1;var r=n.getOrCreate(e);if(typeof r?.has!=`function`||!r.has(t)||typeof r.update!=`function`)return!1;var i=r.update(t,function(e){try{if(e?.id!==t)return e;var n=Object.create(Object.getPrototypeOf(e));return Object.defineProperties(n,Object.getOwnPropertyDescriptors(e)),typeof n.content==`string`&&(n.content=n.content.endsWith(he)?n.content.slice(0,-he.length):n.content+he),n}catch{return e}});return n.commit(i),_e||(_e=!0,queueMicrotask(function(){_e=!1;try{valenced.discord.flux.Stores.MessageStore?.emitChange?.()}catch(e){m(`${me} redraw emit failed:`,e)}})),!0}catch(e){return m(`${me} redraw failed:`,e),!1}}var S={AD:`Andorra`,AE:`United Arab Emirates`,AF:`Afghanistan`,AG:`Antigua & Barbuda`,AI:`Anguilla`,AL:`Albania`,AM:`Armenia`,AO:`Angola`,AQ:`Antarctica`,AR:`Argentina`,AS:`Samoa (American)`,AT:`Austria`,AU:`Australia`,AW:`Aruba`,AX:`Åland Islands`,AZ:`Azerbaijan`,BA:`Bosnia & Herzegovina`,BB:`Barbados`,BD:`Bangladesh`,BE:`Belgium`,BF:`Burkina Faso`,BG:`Bulgaria`,BH:`Bahrain`,BI:`Burundi`,BJ:`Benin`,BL:`St Barthelemy`,BM:`Bermuda`,BN:`Brunei`,BO:`Bolivia`,BQ:`Caribbean NL`,BR:`Brazil`,BS:`Bahamas`,BT:`Bhutan`,BV:`Bouvet Island`,BW:`Botswana`,BY:`Belarus`,BZ:`Belize`,CA:`Canada`,CC:`Cocos (Keeling) Islands`,CD:`Congo (Dem. Rep.)`,CF:`Central African Rep.`,CG:`Congo (Rep.)`,CH:`Switzerland`,CI:`Côte d’Ivoire`,CK:`Cook Islands`,CL:`Chile`,CM:`Cameroon`,CN:`China`,CO:`Colombia`,CR:`Costa Rica`,CU:`Cuba`,CV:`Cape Verde`,CW:`Curaçao`,CX:`Christmas Island`,CY:`Cyprus`,CZ:`Czech Republic`,DE:`Germany`,DJ:`Djibouti`,DK:`Denmark`,DM:`Dominica`,DO:`Dominican Republic`,DZ:`Algeria`,EC:`Ecuador`,EE:`Estonia`,EG:`Egypt`,EH:`Western Sahara`,ER:`Eritrea`,ES:`Spain`,ET:`Ethiopia`,FI:`Finland`,FJ:`Fiji`,FK:`Falkland Islands`,FM:`Micronesia`,FO:`Faroe Islands`,FR:`France`,GA:`Gabon`,GB:`Britain (UK)`,GD:`Grenada`,GE:`Georgia`,GF:`French Guiana`,GG:`Guernsey`,GH:`Ghana`,GI:`Gibraltar`,GL:`Greenland`,GM:`Gambia`,GN:`Guinea`,GP:`Guadeloupe`,GQ:`Equatorial Guinea`,GR:`Greece`,GS:`South Georgia & the South Sandwich Islands`,GT:`Guatemala`,GU:`Guam`,GW:`Guinea-Bissau`,GY:`Guyana`,HK:`Hong Kong`,HM:`Heard Island & McDonald Islands`,HN:`Honduras`,HR:`Croatia`,HT:`Haiti`,HU:`Hungary`,ID:`Indonesia`,IE:`Ireland`,IL:`Israel`,IM:`Isle of Man`,IN:`India`,IO:`British Indian Ocean Territory`,IQ:`Iraq`,IR:`Iran`,IS:`Iceland`,IT:`Italy`,JE:`Jersey`,JM:`Jamaica`,JO:`Jordan`,JP:`Japan`,KE:`Kenya`,KG:`Kyrgyzstan`,KH:`Cambodia`,KI:`Kiribati`,KM:`Comoros`,KN:`St Kitts & Nevis`,KP:`Korea (North)`,KR:`Korea (South)`,KW:`Kuwait`,KY:`Cayman Islands`,KZ:`Kazakhstan`,LA:`Laos`,LB:`Lebanon`,LC:`St Lucia`,LI:`Liechtenstein`,LK:`Sri Lanka`,LR:`Liberia`,LS:`Lesotho`,LT:`Lithuania`,LU:`Luxembourg`,LV:`Latvia`,LY:`Libya`,MA:`Morocco`,MC:`Monaco`,MD:`Moldova`,ME:`Montenegro`,MF:`St Martin (French)`,MG:`Madagascar`,MH:`Marshall Islands`,MK:`North Macedonia`,ML:`Mali`,MM:`Myanmar (Burma)`,MN:`Mongolia`,MO:`Macau`,MP:`Northern Mariana Islands`,MQ:`Martinique`,MR:`Mauritania`,MS:`Montserrat`,MT:`Malta`,MU:`Mauritius`,MV:`Maldives`,MW:`Malawi`,MX:`Mexico`,MY:`Malaysia`,MZ:`Mozambique`,NA:`Namibia`,NC:`New Caledonia`,NE:`Niger`,NF:`Norfolk Island`,NG:`Nigeria`,NI:`Nicaragua`,NL:`Netherlands`,NO:`Norway`,NP:`Nepal`,NR:`Nauru`,NU:`Niue`,NZ:`New Zealand`,OM:`Oman`,PA:`Panama`,PE:`Peru`,PF:`French Polynesia`,PG:`Papua New Guinea`,PH:`Philippines`,PK:`Pakistan`,PL:`Poland`,PM:`St Pierre & Miquelon`,PN:`Pitcairn`,PR:`Puerto Rico`,PS:`Palestine`,PT:`Portugal`,PW:`Palau`,PY:`Paraguay`,QA:`Qatar`,RE:`Réunion`,RO:`Romania`,RS:`Serbia`,RU:`Russia`,RW:`Rwanda`,SA:`Saudi Arabia`,SB:`Solomon Islands`,SC:`Seychelles`,SD:`Sudan`,SE:`Sweden`,SG:`Singapore`,SH:`St Helena`,SI:`Slovenia`,SJ:`Svalbard & Jan Mayen`,SK:`Slovakia`,SL:`Sierra Leone`,SM:`San Marino`,SN:`Senegal`,SO:`Somalia`,SR:`Suriname`,SS:`South Sudan`,ST:`Sao Tome & Principe`,SV:`El Salvador`,SX:`St Maarten (Dutch)`,SY:`Syria`,SZ:`Eswatini (Swaziland)`,TC:`Turks & Caicos Is`,TD:`Chad`,TF:`French S. Terr.`,TG:`Togo`,TH:`Thailand`,TJ:`Tajikistan`,TK:`Tokelau`,TL:`East Timor`,TM:`Turkmenistan`,TN:`Tunisia`,TO:`Tonga`,TR:`Turkey`,TT:`Trinidad & Tobago`,TV:`Tuvalu`,TW:`Taiwan`,TZ:`Tanzania`,UA:`Ukraine`,UG:`Uganda`,UM:`US minor outlying islands`,US:`United States`,UY:`Uruguay`,UZ:`Uzbekistan`,VA:`Vatican City`,VC:`St Vincent`,VE:`Venezuela`,VG:`Virgin Islands (UK)`,VI:`Virgin Islands (US)`,VN:`Vietnam`,VU:`Vanuatu`,WF:`Wallis & Futuna`,WS:`Samoa (western)`,YE:`Yemen`,YT:`Mayotte`,ZA:`South Africa`,ZM:`Zambia`,ZW:`Zimbabwe`},be=`AD|Europe/Andorra|
AE|Asia/Dubai|
AF|Asia/Kabul|
AG|America/Antigua|
AI|America/Anguilla|
AL|Europe/Tirane|
AM|Asia/Yerevan|
AO|Africa/Luanda|
AQ|Antarctica/McMurdo|New Zealand time - McMurdo, South Pole
AQ|Antarctica/Casey|Casey
AQ|Antarctica/Davis|Davis
AQ|Antarctica/DumontDUrville|Dumont-d'Urville
AQ|Antarctica/Mawson|Mawson
AQ|Antarctica/Palmer|Palmer
AQ|Antarctica/Rothera|Rothera
AQ|Antarctica/Syowa|Syowa
AQ|Antarctica/Troll|Troll
AQ|Antarctica/Vostok|Vostok
AR|America/Argentina/Buenos_Aires|Buenos Aires (BA, CF)
AR|America/Argentina/Cordoba|Argentina (most areas: CB, CC, CN, ER, FM, MN, SE, SF)
AR|America/Argentina/Salta|Salta (SA, LP, NQ, RN)
AR|America/Argentina/Jujuy|Jujuy (JY)
AR|America/Argentina/Tucuman|Tucuman (TM)
AR|America/Argentina/Catamarca|Catamarca (CT), Chubut (CH)
AR|America/Argentina/La_Rioja|La Rioja (LR)
AR|America/Argentina/San_Juan|San Juan (SJ)
AR|America/Argentina/Mendoza|Mendoza (MZ)
AR|America/Argentina/San_Luis|San Luis (SL)
AR|America/Argentina/Rio_Gallegos|Santa Cruz (SC)
AR|America/Argentina/Ushuaia|Tierra del Fuego (TF)
AS|Pacific/Pago_Pago|
AT|Europe/Vienna|
AU|Australia/Lord_Howe|Lord Howe Island
AU|Antarctica/Macquarie|Macquarie Island
AU|Australia/Hobart|Tasmania
AU|Australia/Melbourne|Victoria
AU|Australia/Sydney|New South Wales (most areas)
AU|Australia/Broken_Hill|New South Wales (Yancowinna)
AU|Australia/Brisbane|Queensland (most areas)
AU|Australia/Lindeman|Queensland (Whitsunday Islands)
AU|Australia/Adelaide|South Australia
AU|Australia/Darwin|Northern Territory
AU|Australia/Perth|Western Australia (most areas)
AU|Australia/Eucla|Western Australia (Eucla)
AW|America/Aruba|
AX|Europe/Mariehamn|
AZ|Asia/Baku|
BA|Europe/Sarajevo|
BB|America/Barbados|
BD|Asia/Dhaka|
BE|Europe/Brussels|
BF|Africa/Ouagadougou|
BG|Europe/Sofia|
BH|Asia/Bahrain|
BI|Africa/Bujumbura|
BJ|Africa/Porto-Novo|
BL|America/St_Barthelemy|
BM|Atlantic/Bermuda|
BN|Asia/Brunei|
BO|America/La_Paz|
BQ|America/Kralendijk|
BR|America/Noronha|Atlantic islands
BR|America/Belem|Para (east), Amapa
BR|America/Fortaleza|Brazil (northeast: MA, PI, CE, RN, PB)
BR|America/Recife|Pernambuco
BR|America/Araguaina|Tocantins
BR|America/Maceio|Alagoas, Sergipe
BR|America/Bahia|Bahia
BR|America/Sao_Paulo|Brazil (southeast: GO, DF, MG, ES, RJ, SP, PR, SC, RS)
BR|America/Campo_Grande|Mato Grosso do Sul
BR|America/Cuiaba|Mato Grosso
BR|America/Santarem|Para (west)
BR|America/Porto_Velho|Rondonia
BR|America/Boa_Vista|Roraima
BR|America/Manaus|Amazonas (east)
BR|America/Eirunepe|Amazonas (west)
BR|America/Rio_Branco|Acre
BS|America/Nassau|
BT|Asia/Thimphu|
BW|Africa/Gaborone|
BY|Europe/Minsk|
BZ|America/Belize|
CA|America/St_Johns|Newfoundland, Labrador (SE)
CA|America/Halifax|Atlantic - NS (most areas), PE
CA|America/Glace_Bay|Atlantic - NS (Cape Breton)
CA|America/Moncton|Atlantic - New Brunswick
CA|America/Goose_Bay|Atlantic - Labrador (most areas)
CA|America/Blanc-Sablon|AST - QC (Lower North Shore)
CA|America/Toronto|Eastern - ON & QC (most areas)
CA|America/Iqaluit|Eastern - NU (most areas)
CA|America/Atikokan|EST - ON (Atikokan), NU (Coral H)
CA|America/Winnipeg|EST - Manitoba, ON (northwest)
CA|America/Resolute|Central - NU (Resolute)
CA|America/Rankin_Inlet|Central - NU (central)
CA|America/Regina|CST - SK (most areas)
CA|America/Swift_Current|CST - SK (midwest)
CA|America/Edmonton|CST - AB, BC(E), NT(E), SK(W)
CA|America/Cambridge_Bay|Mountain - NU (west)
CA|America/Inuvik|CST - NT (west)
CA|America/Vancouver|MST - BC (most areas)
CA|America/Creston|MST - BC (Creston)
CA|America/Dawson_Creek|MST - BC (Dawson Cr, Ft St John)
CA|America/Fort_Nelson|MST - BC (Ft Nelson)
CA|America/Whitehorse|MST - Yukon (east)
CA|America/Dawson|MST - Yukon (west)
CC|Indian/Cocos|
CD|Africa/Kinshasa|Dem. Rep. of Congo (west)
CD|Africa/Lubumbashi|Dem. Rep. of Congo (east)
CF|Africa/Bangui|
CG|Africa/Brazzaville|
CH|Europe/Zurich|
CI|Africa/Abidjan|
CK|Pacific/Rarotonga|
CL|America/Santiago|most of Chile
CL|America/Coyhaique|Aysen Region
CL|America/Punta_Arenas|Magallanes Region
CL|Pacific/Easter|Easter Island
CM|Africa/Douala|
CN|Asia/Shanghai|Beijing Time
CN|Asia/Urumqi|Xinjiang Time
CO|America/Bogota|
CR|America/Costa_Rica|
CU|America/Havana|
CV|Atlantic/Cape_Verde|
CW|America/Curacao|
CX|Indian/Christmas|
CY|Asia/Nicosia|most of Cyprus
CY|Asia/Famagusta|Northern Cyprus
CZ|Europe/Prague|
DE|Europe/Berlin|most of Germany
DE|Europe/Busingen|Busingen
DJ|Africa/Djibouti|
DK|Europe/Copenhagen|
DM|America/Dominica|
DO|America/Santo_Domingo|
DZ|Africa/Algiers|
EC|America/Guayaquil|Ecuador (mainland)
EC|Pacific/Galapagos|Galapagos Islands
EE|Europe/Tallinn|
EG|Africa/Cairo|
EH|Africa/El_Aaiun|
ER|Africa/Asmara|
ES|Europe/Madrid|Spain (mainland)
ES|Africa/Ceuta|Ceuta, Melilla
ES|Atlantic/Canary|Canary Islands
ET|Africa/Addis_Ababa|
FI|Europe/Helsinki|
FJ|Pacific/Fiji|
FK|Atlantic/Stanley|
FM|Pacific/Chuuk|Chuuk/Truk, Yap
FM|Pacific/Pohnpei|Pohnpei/Ponape
FM|Pacific/Kosrae|Kosrae
FO|Atlantic/Faroe|
FR|Europe/Paris|
GA|Africa/Libreville|
GB|Europe/London|
GD|America/Grenada|
GE|Asia/Tbilisi|
GF|America/Cayenne|
GG|Europe/Guernsey|
GH|Africa/Accra|
GI|Europe/Gibraltar|
GL|America/Nuuk|most of Greenland
GL|America/Danmarkshavn|National Park (east coast)
GL|America/Scoresbysund|Scoresbysund/Ittoqqortoormiit
GL|America/Thule|Thule/Pituffik
GM|Africa/Banjul|
GN|Africa/Conakry|
GP|America/Guadeloupe|
GQ|Africa/Malabo|
GR|Europe/Athens|
GS|Atlantic/South_Georgia|
GT|America/Guatemala|
GU|Pacific/Guam|
GW|Africa/Bissau|
GY|America/Guyana|
HK|Asia/Hong_Kong|
HN|America/Tegucigalpa|
HR|Europe/Zagreb|
HT|America/Port-au-Prince|
HU|Europe/Budapest|
ID|Asia/Jakarta|Java, Sumatra
ID|Asia/Pontianak|Borneo (west, central)
ID|Asia/Makassar|Borneo (east, south), Sulawesi/Celebes, Bali, Nusa Tengarra, Timor (west)
ID|Asia/Jayapura|New Guinea (West Papua / Irian Jaya), Malukus/Moluccas
IE|Europe/Dublin|
IL|Asia/Jerusalem|
IM|Europe/Isle_of_Man|
IN|Asia/Kolkata|
IO|Indian/Chagos|
IQ|Asia/Baghdad|
IR|Asia/Tehran|
IS|Atlantic/Reykjavik|
IT|Europe/Rome|
JE|Europe/Jersey|
JM|America/Jamaica|
JO|Asia/Amman|
JP|Asia/Tokyo|
KE|Africa/Nairobi|
KG|Asia/Bishkek|
KH|Asia/Phnom_Penh|
KI|Pacific/Tarawa|Gilbert Islands
KI|Pacific/Kanton|Phoenix Islands
KI|Pacific/Kiritimati|Line Islands
KM|Indian/Comoro|
KN|America/St_Kitts|
KP|Asia/Pyongyang|
KR|Asia/Seoul|
KW|Asia/Kuwait|
KY|America/Cayman|
KZ|Asia/Almaty|most of Kazakhstan
KZ|Asia/Qyzylorda|Qyzylorda/Kyzylorda/Kzyl-Orda
KZ|Asia/Qostanay|Qostanay/Kostanay/Kustanay
KZ|Asia/Aqtobe|Aqtobe/Aktobe
KZ|Asia/Aqtau|Mangghystau/Mankistau
KZ|Asia/Atyrau|Atyrau/Atirau/Gur'yev
KZ|Asia/Oral|West Kazakhstan
LA|Asia/Vientiane|
LB|Asia/Beirut|
LC|America/St_Lucia|
LI|Europe/Vaduz|
LK|Asia/Colombo|
LR|Africa/Monrovia|
LS|Africa/Maseru|
LT|Europe/Vilnius|
LU|Europe/Luxembourg|
LV|Europe/Riga|
LY|Africa/Tripoli|
MA|Africa/Casablanca|
MC|Europe/Monaco|
MD|Europe/Chisinau|
ME|Europe/Podgorica|
MF|America/Marigot|
MG|Indian/Antananarivo|
MH|Pacific/Majuro|most of Marshall Islands
MH|Pacific/Kwajalein|Kwajalein
MK|Europe/Skopje|
ML|Africa/Bamako|
MM|Asia/Yangon|
MN|Asia/Ulaanbaatar|most of Mongolia
MN|Asia/Hovd|Bayan-Olgii, Hovd, Uvs
MO|Asia/Macau|
MP|Pacific/Saipan|
MQ|America/Martinique|
MR|Africa/Nouakchott|
MS|America/Montserrat|
MT|Europe/Malta|
MU|Indian/Mauritius|
MV|Indian/Maldives|
MW|Africa/Blantyre|
MX|America/Mexico_City|Central Mexico
MX|America/Cancun|Quintana Roo
MX|America/Merida|Campeche, Yucatan
MX|America/Monterrey|Durango; Coahuila, Nuevo Leon, Tamaulipas (most areas)
MX|America/Matamoros|Coahuila, Nuevo Leon, Tamaulipas (US border)
MX|America/Chihuahua|Chihuahua (most areas)
MX|America/Ciudad_Juarez|Chihuahua (US border - west)
MX|America/Ojinaga|Chihuahua (US border - east)
MX|America/Mazatlan|Baja California Sur, Nayarit (most areas), Sinaloa
MX|America/Bahia_Banderas|Bahia de Banderas
MX|America/Hermosillo|Sonora
MX|America/Tijuana|Baja California
MY|Asia/Kuala_Lumpur|Malaysia (peninsula)
MY|Asia/Kuching|Sabah, Sarawak
MZ|Africa/Maputo|
NA|Africa/Windhoek|
NC|Pacific/Noumea|
NE|Africa/Niamey|
NF|Pacific/Norfolk|
NG|Africa/Lagos|
NI|America/Managua|
NL|Europe/Amsterdam|
NO|Europe/Oslo|
NP|Asia/Kathmandu|
NR|Pacific/Nauru|
NU|Pacific/Niue|
NZ|Pacific/Auckland|most of New Zealand
NZ|Pacific/Chatham|Chatham Islands
OM|Asia/Muscat|
PA|America/Panama|
PE|America/Lima|
PF|Pacific/Tahiti|Society Islands
PF|Pacific/Marquesas|Marquesas Islands
PF|Pacific/Gambier|Gambier Islands
PG|Pacific/Port_Moresby|most of Papua New Guinea
PG|Pacific/Bougainville|Bougainville
PH|Asia/Manila|
PK|Asia/Karachi|
PL|Europe/Warsaw|
PM|America/Miquelon|
PN|Pacific/Pitcairn|
PR|America/Puerto_Rico|
PS|Asia/Gaza|Gaza Strip
PS|Asia/Hebron|West Bank
PT|Europe/Lisbon|Portugal (mainland)
PT|Atlantic/Madeira|Madeira Islands
PT|Atlantic/Azores|Azores
PW|Pacific/Palau|
PY|America/Asuncion|
QA|Asia/Qatar|
RE|Indian/Reunion|
RO|Europe/Bucharest|
RS|Europe/Belgrade|
RU|Europe/Kaliningrad|MSK-01 - Kaliningrad
RU|Europe/Moscow|MSK+00 - Moscow area
UA|Europe/Simferopol|Crimea
RU|Europe/Kirov|MSK+00 - Kirov
RU|Europe/Volgograd|MSK+00 - Volgograd
RU|Europe/Astrakhan|MSK+01 - Astrakhan
RU|Europe/Saratov|MSK+01 - Saratov
RU|Europe/Ulyanovsk|MSK+01 - Ulyanovsk
RU|Europe/Samara|MSK+01 - Samara, Udmurtia
RU|Asia/Yekaterinburg|MSK+02 - Urals
RU|Asia/Omsk|MSK+03 - Omsk
RU|Asia/Novosibirsk|MSK+04 - Novosibirsk
RU|Asia/Barnaul|MSK+04 - Altai
RU|Asia/Tomsk|MSK+04 - Tomsk
RU|Asia/Novokuznetsk|MSK+04 - Kemerovo
RU|Asia/Krasnoyarsk|MSK+04 - Krasnoyarsk area
RU|Asia/Irkutsk|MSK+05 - Irkutsk, Buryatia
RU|Asia/Chita|MSK+06 - Zabaykalsky
RU|Asia/Yakutsk|MSK+06 - Lena River
RU|Asia/Khandyga|MSK+06 - Tomponsky, Ust-Maysky
RU|Asia/Vladivostok|MSK+07 - Amur River
RU|Asia/Ust-Nera|MSK+07 - Oymyakonsky
RU|Asia/Magadan|MSK+08 - Magadan
RU|Asia/Sakhalin|MSK+08 - Sakhalin Island
RU|Asia/Srednekolymsk|MSK+08 - Sakha (E), N Kuril Is
RU|Asia/Kamchatka|MSK+09 - Kamchatka
RU|Asia/Anadyr|MSK+09 - Bering Sea
RW|Africa/Kigali|
SA|Asia/Riyadh|
SB|Pacific/Guadalcanal|
SC|Indian/Mahe|
SD|Africa/Khartoum|
SE|Europe/Stockholm|
SG|Asia/Singapore|
SH|Atlantic/St_Helena|
SI|Europe/Ljubljana|
SJ|Arctic/Longyearbyen|
SK|Europe/Bratislava|
SL|Africa/Freetown|
SM|Europe/San_Marino|
SN|Africa/Dakar|
SO|Africa/Mogadishu|
SR|America/Paramaribo|
SS|Africa/Juba|
ST|Africa/Sao_Tome|
SV|America/El_Salvador|
SX|America/Lower_Princes|
SY|Asia/Damascus|
SZ|Africa/Mbabane|
TC|America/Grand_Turk|
TD|Africa/Ndjamena|
TF|Indian/Kerguelen|
TG|Africa/Lome|
TH|Asia/Bangkok|
TJ|Asia/Dushanbe|
TK|Pacific/Fakaofo|
TL|Asia/Dili|
TM|Asia/Ashgabat|
TN|Africa/Tunis|
TO|Pacific/Tongatapu|
TR|Europe/Istanbul|
TT|America/Port_of_Spain|
TV|Pacific/Funafuti|
TW|Asia/Taipei|
TZ|Africa/Dar_es_Salaam|
UA|Europe/Kyiv|most of Ukraine
UG|Africa/Kampala|
UM|Pacific/Midway|Midway Islands
UM|Pacific/Wake|Wake Island
US|America/New_York|Eastern (most areas)
US|America/Detroit|Eastern - MI (most areas)
US|America/Kentucky/Louisville|Eastern - KY (Louisville area)
US|America/Kentucky/Monticello|Eastern - KY (Wayne)
US|America/Indiana/Indianapolis|Eastern - IN (most areas)
US|America/Indiana/Vincennes|Eastern - IN (Da, Du, K, Mn)
US|America/Indiana/Winamac|Eastern - IN (Pulaski)
US|America/Indiana/Marengo|Eastern - IN (Crawford)
US|America/Indiana/Petersburg|Eastern - IN (Pike)
US|America/Indiana/Vevay|Eastern - IN (Switzerland)
US|America/Chicago|Central (most areas)
US|America/Indiana/Tell_City|Central - IN (Perry)
US|America/Indiana/Knox|Central - IN (Starke)
US|America/Menominee|Central - MI (Wisconsin border)
US|America/North_Dakota/Center|Central - ND (Oliver)
US|America/North_Dakota/New_Salem|Central - ND (Morton rural)
US|America/North_Dakota/Beulah|Central - ND (Mercer)
US|America/Denver|Mountain (most areas)
US|America/Boise|Mountain - ID (south), OR (east)
US|America/Phoenix|MST - AZ (except Navajo)
US|America/Los_Angeles|Pacific
US|America/Anchorage|Alaska (most areas)
US|America/Juneau|Alaska - Juneau area
US|America/Sitka|Alaska - Sitka area
US|America/Metlakatla|Alaska - Annette Island
US|America/Yakutat|Alaska - Yakutat
US|America/Nome|Alaska (west)
US|America/Adak|Alaska - western Aleutians
US|Pacific/Honolulu|Hawaii
UY|America/Montevideo|
UZ|Asia/Samarkand|Uzbekistan (west)
UZ|Asia/Tashkent|Uzbekistan (east)
VA|Europe/Vatican|
VC|America/St_Vincent|
VE|America/Caracas|
VG|America/Tortola|
VI|America/St_Thomas|
VN|Asia/Ho_Chi_Minh|
VU|Pacific/Efate|
WF|Pacific/Wallis|
WS|Pacific/Apia|
YE|Asia/Aden|
YT|Indian/Mayotte|
ZA|Africa/Johannesburg|
ZM|Africa/Lusaka|
ZW|Africa/Harare|`,xe=`Australia/ACT|Australia/Sydney
Australia/LHI|Australia/Lord_Howe
Australia/NSW|Australia/Sydney
Australia/North|Australia/Darwin
Australia/Queensland|Australia/Brisbane
Australia/South|Australia/Adelaide
Australia/Tasmania|Australia/Hobart
Australia/Victoria|Australia/Melbourne
Australia/West|Australia/Perth
Australia/Yancowinna|Australia/Broken_Hill
Brazil/Acre|America/Rio_Branco
Brazil/DeNoronha|America/Noronha
Brazil/East|America/Sao_Paulo
Brazil/West|America/Manaus
Canada/Atlantic|America/Halifax
Canada/Central|America/Winnipeg
Canada/Eastern|America/Toronto
Canada/Mountain|America/Edmonton
Canada/Newfoundland|America/St_Johns
Canada/Pacific|America/Vancouver
Canada/Saskatchewan|America/Regina
Canada/Yukon|America/Whitehorse
Chile/Continental|America/Santiago
Chile/EasterIsland|Pacific/Easter
Mexico/BajaNorte|America/Tijuana
Mexico/BajaSur|America/Mazatlan
Mexico/General|America/Mexico_City
US/Alaska|America/Anchorage
US/Aleutian|America/Adak
US/Arizona|America/Phoenix
US/Central|America/Chicago
US/East-Indiana|America/Indiana/Indianapolis
US/Eastern|America/New_York
US/Hawaii|Pacific/Honolulu
US/Indiana-Starke|America/Indiana/Knox
US/Michigan|America/Detroit
US/Mountain|America/Denver
US/Pacific|America/Los_Angeles
US/Samoa|Pacific/Pago_Pago
America/Buenos_Aires|America/Argentina/Buenos_Aires
America/Catamarca|America/Argentina/Catamarca
America/Cordoba|America/Argentina/Cordoba
America/Indianapolis|America/Indiana/Indianapolis
America/Jujuy|America/Argentina/Jujuy
America/Knox_IN|America/Indiana/Knox
America/Louisville|America/Kentucky/Louisville
America/Mendoza|America/Argentina/Mendoza
America/Virgin|America/Puerto_Rico
Pacific/Samoa|Pacific/Pago_Pago
Africa/Accra|Africa/Abidjan
Africa/Addis_Ababa|Africa/Nairobi
Africa/Asmara|Africa/Nairobi
Africa/Bamako|Africa/Abidjan
Africa/Bangui|Africa/Lagos
Africa/Banjul|Africa/Abidjan
Africa/Blantyre|Africa/Maputo
Africa/Brazzaville|Africa/Lagos
Africa/Bujumbura|Africa/Maputo
Africa/Conakry|Africa/Abidjan
Africa/Dakar|Africa/Abidjan
Africa/Dar_es_Salaam|Africa/Nairobi
Africa/Djibouti|Africa/Nairobi
Africa/Douala|Africa/Lagos
Africa/Freetown|Africa/Abidjan
Africa/Gaborone|Africa/Maputo
Africa/Harare|Africa/Maputo
Africa/Kampala|Africa/Nairobi
Africa/Kigali|Africa/Maputo
Africa/Kinshasa|Africa/Lagos
Africa/Libreville|Africa/Lagos
Africa/Lome|Africa/Abidjan
Africa/Luanda|Africa/Lagos
Africa/Lubumbashi|Africa/Maputo
Africa/Lusaka|Africa/Maputo
Africa/Malabo|Africa/Lagos
Africa/Maseru|Africa/Johannesburg
Africa/Mbabane|Africa/Johannesburg
Africa/Mogadishu|Africa/Nairobi
Africa/Niamey|Africa/Lagos
Africa/Nouakchott|Africa/Abidjan
Africa/Ouagadougou|Africa/Abidjan
Africa/Porto-Novo|Africa/Lagos
America/Anguilla|America/Puerto_Rico
America/Antigua|America/Puerto_Rico
America/Aruba|America/Puerto_Rico
America/Atikokan|America/Panama
America/Blanc-Sablon|America/Puerto_Rico
America/Cayman|America/Panama
America/Creston|America/Phoenix
America/Curacao|America/Puerto_Rico
America/Dominica|America/Puerto_Rico
America/Grenada|America/Puerto_Rico
America/Guadeloupe|America/Puerto_Rico
America/Kralendijk|America/Puerto_Rico
America/Lower_Princes|America/Puerto_Rico
America/Marigot|America/Puerto_Rico
America/Montserrat|America/Puerto_Rico
America/Nassau|America/Toronto
America/Port_of_Spain|America/Puerto_Rico
America/St_Barthelemy|America/Puerto_Rico
America/St_Kitts|America/Puerto_Rico
America/St_Lucia|America/Puerto_Rico
America/St_Thomas|America/Puerto_Rico
America/St_Vincent|America/Puerto_Rico
America/Tortola|America/Puerto_Rico
Antarctica/DumontDUrville|Pacific/Port_Moresby
Antarctica/McMurdo|Pacific/Auckland
Antarctica/Syowa|Asia/Riyadh
Arctic/Longyearbyen|Europe/Berlin
Asia/Aden|Asia/Riyadh
Asia/Bahrain|Asia/Qatar
Asia/Brunei|Asia/Kuching
Asia/Kuala_Lumpur|Asia/Singapore
Asia/Kuwait|Asia/Riyadh
Asia/Muscat|Asia/Dubai
Asia/Phnom_Penh|Asia/Bangkok
Asia/Vientiane|Asia/Bangkok
Atlantic/Reykjavik|Africa/Abidjan
Atlantic/St_Helena|Africa/Abidjan
Europe/Amsterdam|Europe/Brussels
Europe/Bratislava|Europe/Prague
Europe/Busingen|Europe/Zurich
Europe/Copenhagen|Europe/Berlin
Europe/Guernsey|Europe/London
Europe/Isle_of_Man|Europe/London
Europe/Jersey|Europe/London
Europe/Ljubljana|Europe/Belgrade
Europe/Luxembourg|Europe/Brussels
Europe/Mariehamn|Europe/Helsinki
Europe/Monaco|Europe/Paris
Europe/Oslo|Europe/Berlin
Europe/Podgorica|Europe/Belgrade
Europe/San_Marino|Europe/Rome
Europe/Sarajevo|Europe/Belgrade
Europe/Skopje|Europe/Belgrade
Europe/Stockholm|Europe/Berlin
Europe/Vaduz|Europe/Zurich
Europe/Vatican|Europe/Rome
Europe/Zagreb|Europe/Belgrade
Indian/Antananarivo|Africa/Nairobi
Indian/Christmas|Asia/Bangkok
Indian/Cocos|Asia/Yangon
Indian/Comoro|Africa/Nairobi
Indian/Kerguelen|Indian/Maldives
Indian/Mahe|Asia/Dubai
Indian/Mayotte|Africa/Nairobi
Indian/Reunion|Asia/Dubai
Pacific/Chuuk|Pacific/Port_Moresby
Pacific/Funafuti|Pacific/Tarawa
Pacific/Majuro|Pacific/Tarawa
Pacific/Midway|Pacific/Pago_Pago
Pacific/Pohnpei|Pacific/Guadalcanal
Pacific/Saipan|Pacific/Guam
Pacific/Wake|Pacific/Tarawa
Pacific/Wallis|Pacific/Tarawa
Africa/Timbuktu|Africa/Abidjan
America/Argentina/ComodRivadavia|America/Argentina/Catamarca
America/Atka|America/Adak
America/Coral_Harbour|America/Panama
America/Ensenada|America/Tijuana
America/Fort_Wayne|America/Indiana/Indianapolis
America/Montreal|America/Toronto
America/Nipigon|America/Toronto
America/Pangnirtung|America/Iqaluit
America/Porto_Acre|America/Rio_Branco
America/Rainy_River|America/Winnipeg
America/Rosario|America/Argentina/Cordoba
America/Santa_Isabel|America/Tijuana
America/Shiprock|America/Denver
America/Thunder_Bay|America/Toronto
America/Yellowknife|America/Edmonton
Antarctica/South_Pole|Pacific/Auckland
Asia/Choibalsan|Asia/Ulaanbaatar
Asia/Chongqing|Asia/Shanghai
Asia/Harbin|Asia/Shanghai
Asia/Kashgar|Asia/Urumqi
Asia/Tel_Aviv|Asia/Jerusalem
Atlantic/Jan_Mayen|Europe/Berlin
Australia/Canberra|Australia/Sydney
Australia/Currie|Australia/Hobart
Europe/Belfast|Europe/London
Europe/Tiraspol|Europe/Chisinau
Europe/Uzhgorod|Europe/Kyiv
Europe/Zaporozhye|Europe/Kyiv
Pacific/Enderbury|Pacific/Kanton
Pacific/Johnston|Pacific/Honolulu
Pacific/Yap|Pacific/Port_Moresby
Africa/Asmera|Africa/Nairobi
America/Godthab|America/Nuuk
Asia/Ashkhabad|Asia/Ashgabat
Asia/Calcutta|Asia/Kolkata
Asia/Chungking|Asia/Shanghai
Asia/Dacca|Asia/Dhaka
Asia/Istanbul|Europe/Istanbul
Asia/Katmandu|Asia/Kathmandu
Asia/Macao|Asia/Macau
Asia/Rangoon|Asia/Yangon
Asia/Saigon|Asia/Ho_Chi_Minh
Asia/Thimbu|Asia/Thimphu
Asia/Ujung_Pandang|Asia/Makassar
Asia/Ulan_Bator|Asia/Ulaanbaatar
Atlantic/Faeroe|Atlantic/Faroe
Europe/Kiev|Europe/Kyiv
Europe/Nicosia|Asia/Nicosia
Pacific/Ponape|Pacific/Guadalcanal
Pacific/Truk|Pacific/Port_Moresby`,Se=/* @__PURE__ */ `Pacific/Honolulu.America/Anchorage.America/Los_Angeles.America/Vancouver.America/Tijuana.America/Phoenix.America/Denver.America/Edmonton.America/Chicago.America/Mexico_City.America/Winnipeg.America/New_York.America/Toronto.America/Detroit.America/Panama.America/Bogota.America/Lima.America/Caracas.America/Halifax.America/Puerto_Rico.America/Santiago.America/St_Johns.America/Sao_Paulo.America/Recife.America/Argentina/Buenos_Aires.America/Montevideo.Atlantic/Azores.Atlantic/Reykjavik.Europe/London.Europe/Dublin.Europe/Lisbon.Africa/Casablanca.Africa/Lagos.Europe/Paris.Europe/Brussels.Europe/Amsterdam.Europe/Berlin.Europe/Zurich.Europe/Vienna.Europe/Rome.Europe/Madrid.Europe/Stockholm.Europe/Oslo.Europe/Copenhagen.Europe/Prague.Europe/Warsaw.Europe/Budapest.Europe/Belgrade.Africa/Johannesburg.Africa/Cairo.Europe/Athens.Europe/Bucharest.Europe/Helsinki.Europe/Kyiv.Asia/Jerusalem.Europe/Istanbul.Europe/Moscow.Africa/Nairobi.Asia/Riyadh.Asia/Baghdad.Asia/Tehran.Asia/Dubai.Asia/Baku.Asia/Kabul.Asia/Karachi.Asia/Tashkent.Asia/Kolkata.Asia/Colombo.Asia/Kathmandu.Asia/Dhaka.Asia/Almaty.Asia/Yangon.Asia/Bangkok.Asia/Ho_Chi_Minh.Asia/Jakarta.Asia/Singapore.Asia/Kuala_Lumpur.Asia/Manila.Asia/Shanghai.Asia/Hong_Kong.Asia/Taipei.Australia/Perth.Asia/Seoul.Asia/Tokyo.Australia/Darwin.Australia/Adelaide.Australia/Brisbane.Australia/Sydney.Australia/Melbourne.Australia/Hobart.Pacific/Guam.Pacific/Noumea.Pacific/Auckland.Pacific/Fiji.Pacific/Tongatapu.Pacific/Kiritimati.UTC`.split(`.`),Ce=/* @__PURE__ */ `-12:00.-11:00.-10:00.-09:30.-09:00.-08:00.-07:00.-06:00.-05:00.-04:00.-03:30.-03:00.-02:00.-01:00.+00:00.+01:00.+02:00.+03:00.+03:30.+04:00.+04:30.+05:00.+05:30.+05:45.+06:00.+06:30.+07:00.+08:00.+08:45.+09:00.+09:30.+10:00.+10:30.+11:00.+12:00.+12:45.+13:00.+14:00`.split(`.`),we=/^(?:UTC|GMT)?\s*([+-])(\d{1,2})(?::?(\d{2}))?$/i;function Te(e){var t=we.exec(e.trim());if(t){var n=Number(t[2]),r=Number(t[3]??0);if(!(n>14||r>59))return`${t[1]}${String(n).padStart(2,`0`)}:${String(r).padStart(2,`0`)}`}}function C(e){var t=Te(e);if(t)return(t[0]===`-`?-1:1)*(Number(t.slice(1,3))*60+Number(t.slice(4,6)))}var Ee=/* @__PURE__ */ new Map;function De(e){if(Ee.has(e))return Ee.get(e)??void 0;var t=null;try{t=new Intl.DateTimeFormat(`en-US`,{timeZone:e,year:`numeric`,month:`2-digit`,day:`2-digit`,hour:`2-digit`,minute:`2-digit`,hour12:!1})}catch{}return Ee.set(e,t),t??void 0}function w(e,t){var n=C(e);if(n!==void 0)return n;var r=De(e);if(r)try{var i=r.format(new Date(t)).match(/\d+/g);if(!i||i.length<5)return;var[a,o,s,c,l]=i.map(Number),u=Date.UTC(s,a-1,o,c%24,l),d=Math.floor(t/6e4)*6e4;return Math.round((u-d)/6e4)}catch{return}}var T;function Oe(){if(T!==void 0)return T;var e=Date.now();return T=w(`Asia/Tokyo`,e)===540&&w(`UTC`,e)===0,T}function ke(e){return C(e)!==void 0||Oe()&&w(e,Date.now())!==void 0}function Ae(e){if(e===0)return`UTC`;var t=e<0?`−`:`+`,n=Math.abs(e),r=n%60;return`UTC${t}${Math.floor(n/60)}${r?`:${String(r).padStart(2,`0`)}`:``}`}var je=[`Sun`,`Mon`,`Tue`,`Wed`,`Thu`,`Fri`,`Sat`];function Me(e,t,n){var r=String(t).padStart(2,`0`);return n?`${String(e).padStart(2,`0`)}:${r}`:`${e%12||12}:${r} ${e>=12?`PM`:`AM`}`}function E(e,t,n){if(Number.isFinite(t)&&(C(e)!==void 0||Oe())){var r=w(e,t);if(r!==void 0){var i=new Date(t+r*6e4),a=new Date(t),o=i.getUTCDay();return{time:Me(i.getUTCHours(),i.getUTCMinutes(),n),otherDay:o===a.getDay()?void 0:je[o],offset:Ae(r)}}}}function D(e){var t=C(e);return t===void 0?(e.split(`/`).pop()??e).replace(/_/g,` `):Ae(t)}function Ne(e){if(typeof e==`string`){var t=e.trim();if(t)return Te(t)??t}}var Pe={usa:`US`,us:`US`,america:`US`,"united states of america":`US`,uk:`GB`,"united kingdom":`GB`,"great britain":`GB`,britain:`GB`,england:`GB`,scotland:`GB`,wales:`GB`,"northern ireland":`GB`,uae:`AE`,emirates:`AE`,"united arab emirates":`AE`,"south korea":`KR`,korea:`KR`,"north korea":`KP`,holland:`NL`,czechia:`CZ`,turkiye:`TR`,burma:`MM`,"ivory coast":`CI`,drc:`CD`,"democratic republic of the congo":`CD`,"republic of the congo":`CG`,swaziland:`SZ`,macao:`MO`,"cape verde":`CV`,"east timor":`TL`,palestine:`PS`,vatican:`VA`,"american samoa":`AS`,samoa:`WS`,bosnia:`BA`,trinidad:`TT`},Fe=/* @__PURE__ */ RegExp(`[̀-ͯ]`,`g`);function O(e){var t=e.toLowerCase();try{t=t.normalize(`NFD`).replace(Fe,``)}catch{}return t.replace(/[_\-/().,'&]+/g,` `).replace(/\s+/g,` `).trim()}var k;function Ie(){if(k)return k;var e=[],t=/* @__PURE__ */ new Map;for(var n of be.split(`
`)){var[r,i,a=``]=n.split(`|`);if(i){var o=D(i),s={zone:i,cc:r,country:S[r]??r,city:o,note:a,cityKey:O(o),pathKey:O(i),noteKey:O(a)};e.push(s);var c=t.get(r)??[];c.push(s),t.set(r,c)}}var l=[];for(var u of xe.split(`
`)){var[d,f]=u.split(`|`);d&&f&&l.push([O(d),d,f])}return k={zones:e,byCountry:t,links:l},k}function Le(e){var t=[],n=[],r=Pe[e];r&&t.push(r);for(var[i,a]of Object.entries(Pe))i!==e&&i.startsWith(e)&&e.length>=3&&!t.includes(a)&&t.push(a);for(var o of Object.keys(S)){var s=O(S[o]);t.includes(o)||(s===e||s.startsWith(e)?t.push(o):e.length>=3&&s.includes(e)&&n.push(o))}return[...t,...n]}function A(e){return{zone:e.zone,title:e.city,detail:e.note?`${e.country} · ${e.note}`:e.country,place:`${e.city}, ${e.country}`}}function Re(e){var t=S[e]??e,n=Ie().byCountry.get(e)??[];return n.length===1?[{zone:n[0].zone,title:t,detail:n[0].city,place:t}]:n.map(function(e){return{zone:e.zone,title:`${t} — ${e.city}`,detail:e.note||void 0,place:`${e.city}, ${t}`}})}function j(e){var t=C(e);if(t!==void 0)return{zone:e,title:Ae(t),detail:`Fixed offset, no daylight saving`};var n=Ie().zones.find(function(t){return t.zone===e});return n?A(n):{zone:e,title:D(e)}}function ze(e,t=60){var n=O(e);if(!n)return Se.map(j).slice(0,t);var{zones:r,links:i}=Ie(),a=[],o=/* @__PURE__ */ new Set,s=function(e){o.has(e.zone)||(o.add(e.zone),a.push(e))},c=Te(e);c&&s(j(c)),(n===`utc`||n===`gmt`)&&s(j(`UTC`));for(var l of Le(n))for(var u of Re(l))s(u);for(var d of r)d.cityKey.startsWith(n)&&s(A(d));var f=new Set(r.map(function(e){return e.zone}));for(var[p,m,h]of i)f.has(m)||((p.split(` `).pop()??p).startsWith(n)||p===n)&&s({...j(h),detail:`Old name: ${m}`});if(n.length>=3){for(var g of r)(g.cityKey.includes(n)||g.pathKey.includes(n))&&s(A(g));for(var _ of r)_.noteKey.includes(n)&&s(A(_))}var v=e.trim();/^[A-Za-z]/.test(v)&&v.length>=3&&!o.has(v)&&ke(v)&&s({zone:v,title:v});var y=v.replace(/^(?:utc|gmt)\s*/i,``);if(/^[+-]\d/.test(y))for(var b of Ce)(b.startsWith(y)||b.replace(/^([+-])0/,`$1`).startsWith(y))&&s(j(b));return a.slice(0,t)}var Be=`[Timezones]`,Ve=`https://timezone.creations.works/list`,He=36e5,Ue=15e3,We=3e4,Ge=6e5,Ke=2e5,qe=/* @__PURE__ */ new Map,Je=0,Ye=!1,Xe=0,M=0,N=!0,P=/* @__PURE__ */ new Set;function Ze(){for(var e of P)try{e()}catch{}}function Qe(e){if(!N&&(Date.now()-Je>He&&$e(),Je))return qe.get(e)??null}async function $e(){if(!(Ye||N||Date.now()<Xe)){Ye=!0;var e=typeof AbortController==`function`?new AbortController:void 0,t=setTimeout(function(){return e?.abort()},Ue);try{var n=await fetch(Ve,{headers:{Accept:`application/json`},credentials:`omit`,signal:e?.signal});if(!n.ok)throw Error(`HTTP ${n.status}`);var r=await n.json();if(!r||typeof r!=`object`)throw Error(`not a list`);var i=/* @__PURE__ */ new Map;for(var a in r){if(i.size>=Ke)break;if(/^\d{15,21}$/.test(a)){var o=Ne(r[a]?.timezone);o&&i.set(a,o)}}if(N)return;qe=i,Je=Date.now(),M=0,Xe=0,Ze()}catch(e){M||m(`${Be} Equicord timezone list failed:`,e),M=M?Math.min(M*2,Ge):We,Xe=Date.now()+M}finally{clearTimeout(t),Ye=!1}}}function et(e){return P.add(e),function(){return P.delete(e)}}function tt(){N=!1,M=0,Xe=0}function nt(){N=!0,qe=/* @__PURE__ */ new Map,Je=0,P.clear()}var rt=`[Timezones]`,it=`https://timezonedb.catvibers.me/api/user/bulk`,at=100,ot=300,st=36e5,ct=1e4,lt=3e4,ut=6e5,dt=/* @__PURE__ */ new Map,F=/* @__PURE__ */ new Set,ft=/* @__PURE__ */ new Set,I=/* @__PURE__ */ new Set,L,R=!1,z=0,B=0;function pt(e){B=B?Math.min(B*2,ut):lt;var t=e&&e>0?Math.min(e,ut):B;z=Date.now()+t}function V(e){L===void 0&&(L=setTimeout(yt,Math.max(e,z-Date.now())))}function mt(e){var t=dt.get(e);if(t&&!(Date.now()-t.at>st))return t.zone??null}function ht(e){!R&&/^\d{15,21}$/.test(e)&&(mt(e)!==void 0||ft.has(e)||F.has(e)||(F.add(e),V(ot)))}function gt(e){dt.delete(e),ht(e)}function _t(e){return I.add(e),function(){return I.delete(e)}}function vt(){for(var e of I)try{e()}catch{}}async function yt(){if(L=void 0,!R&&F.size){if(Date.now()<z)V(0);else{var e=[...F].slice(0,at);for(var t of e)F.delete(t),ft.add(t);F.size&&V(ot);var n=typeof AbortController==`function`?new AbortController:void 0,r=setTimeout(function(){return n?.abort()},ct);try{var i=await fetch(it,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e),signal:n?.signal});if(!i.ok){var a=Number(i.headers?.get?.(`Retry-After`));throw Object.assign(/* @__PURE__ */ Error(`HTTP ${i.status}`),{retryAfterMs:Number.isFinite(a)&&a>0?a*1e3:void 0})}var o=await i.json(),s=Date.now();for(var c of e){var l=o?.[c];dt.set(c,{zone:Ne(l?.timezone),at:s})}B=0,z=0,R||vt()}catch(t){if(B||m(`${rt} shared timezone lookup failed:`,t),pt(t?.retryAfterMs),!R){for(var u of e)F.add(u);V(0)}}finally{clearTimeout(r);for(var d of e)ft.delete(d)}}}}function bt(){R=!1,B=0,z=0}function xt(){R=!0,L!==void 0&&clearTimeout(L),L=void 0,F.clear(),I.clear()}var H={showInChat:!0,sharedLookup:!0,equicordLookup:!1,placeSearch:!0,hour24:!1,showDay:!0,people:{}},U,St,W=!1,G={...H},Ct=/* @__PURE__ */ new Set;function wt(){for(var e of Ct)try{e()}catch{}}function Tt(e){var t={};if(!e||typeof e!=`object`)return t;for(var n of Object.keys(e)){var r=e[n];r&&typeof r.zone==`string`&&(t[n]=r)}return t}function K(e,t){var n={...e,...t??{}};return n.people=Tt(t?.people&&typeof t.people==`object`?{...e.people,...t.people}:e.people),n}function Et(e){if(!(e&&e===U)&&(St?.(),St=void 0,U=e,W=!1,G={...H},e)){var t=e.cache;t&&(G=K(H,t),W=!0),St=e.subscribe?.(function(e,t){G=K(t===0?G:H,e),W=!0,wt()}),Promise.resolve(e.get?.()).then(function(e){e&&(G=K(H,e)),W=!0,wt()}).catch(function(){})}}function Dt(e){!U&&e&&Et(e)}function q(){return G}function J(){var[,e]=valenced.react.React.useReducer(function(e){return e+1},0);return valenced.react.React.useEffect(function(){return kt(e)},[]),G}function Y(e){G={...K(G,e),...e.people?{people:Tt(e.people)}:{}},wt();try{var t=W?U?.set?.(G,!0):U?.set(e);Promise.resolve(t).catch(function(){})}catch{}}function Ot(e,t,n,r){var i={...q().people};n?i[e]={zone:n,name:t,at:Date.now(),...r?{place:r}:{}}:delete i[e],Y({people:i})}function kt(e){return Ct.add(e),function(){return Ct.delete(e)}}function At(e){var t=q(),n=t.people[e];if(n?.zone)return{zone:n.zone,place:n.place,source:`you`};var r=t.sharedLookup?mt(e):null;if(r)return{zone:r,source:`shared`};var i=t.equicordLookup?Qe(e):null;if(i)return{zone:i,source:`equicord`};r===void 0&&ht(e)}var X=`[Timezones]`,jt=` · `;function Mt(e){try{if(e==null)return;if(typeof e==`number`)return e;if(e instanceof Date)return e.getTime();if(typeof e==`string`)return Date.parse(e);if(typeof e.valueOf==`function`){var t=Number(e.valueOf());if(Number.isFinite(t))return t}}catch{}}function Nt(){try{return valenced.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id}catch{return}}function Pt(e,t){var n=q();if(n.showInChat&&t!==void 0&&e!==Nt()){var r=At(e);if(r){var i=E(r.zone,t,n.hour24);if(i)return`${jt}${i.time}${n.showDay&&i.otherDay?` ${i.otherDay}`:``}`}}}function Ft(e,t){if(typeof e!=`string`||!e||e.endsWith(t))return e;var n=e.indexOf(jt);return`${n>0?e.slice(0,n):e}${t}`}var It=200,Z=/* @__PURE__ */ new Map;function Lt(e,t){Z.delete(e),Z.set(e,t),Z.size>It&&Z.delete(Z.keys().next().value)}var Q;function Rt(){Q===void 0&&(Q=setTimeout(function(){Q=void 0;for(var[e,t]of[...Z])try{if(Pt(t.authorId,t.at)===t.shown)continue;var n=e.indexOf(`:`);n>0&&ye(e.slice(0,n),e.slice(n+1))}catch(e){m(`${X} refresh failed:`,e)}},50))}function zt(){var{getModules:e}=valenced.modules.finders,{withName:t}=valenced.modules.finders.filters,n=[],r,i=e(t(`RowManager`),function(e){try{if(typeof e?.prototype?.generate!=`function`){m(`${X} RowManager.prototype.generate not found`,/* @__PURE__ */ Error(`missing`));return}n.push(valenced.patcher.before(e.prototype,`generate`,function(e){return r=e?.[0],e})),n.push(valenced.patcher.after(e.prototype,`generate`,function(e){var t=r;r=void 0;try{if(t?.rowType!==1)return e;var n=t.message,i=n?.author?.id==null?void 0:String(n.author.id);if(!i||!n?.id||!n?.channel_id)return e;var a=Mt(n.timestamp),o=Pt(i,a);if(Lt(`${n.channel_id}:${n.id}`,{authorId:i,at:a,shown:o}),!o)return e;var s=e?.message;s&&s.state===`SENT`&&typeof s.timestamp==`string`&&(s.timestamp=Ft(s.timestamp,o)),typeof n.__customTimestamp==`string`&&(n.__customTimestamp=Ft(n.__customTimestamp,o))}catch(e){m(`${X} chat timestamp failed:`,e)}return e}))}catch(e){m(`${X} could not patch RowManager:`,e)}}),a=_t(function(){return Rt()}),o=et(function(){return Rt()}),s=kt(function(){return Rt()});return function(){a(),o(),s(),i();for(var e of n.reverse())e();r=void 0,Q!==void 0&&clearTimeout(Q),Q=void 0,Z.clear()}}function Bt(e,t,n){if(t&&n){var r=function(e,i,a){if(!(!e||a>40)){if(Array.isArray(e))for(var o of e){var s=r(o,i,a+1);if(s)return s}else if(e.props){var c=i||e.type===t,l=e.props.children;return c&&(Array.isArray(l)?l:[l]).some(function(e){return e?.type===n})?e:r(l,c,a+1)}}};return r(e,!1,0)}}var Vt=`https://geocoding-api.open-meteo.com/v1/search`,Ht=8e3,Ut=10,Wt=/* @__PURE__ */ new Map;async function Gt(e){var t=e.trim(),n=t.toLowerCase(),r=Wt.get(n);if(r)return r;var i=typeof AbortController==`function`?new AbortController:void 0,a=setTimeout(function(){return i?.abort()},Ht);try{var o=function(e){if(typeof e?.timezone!=`string`||typeof e?.name!=`string`)return`continue`;var t=[e.admin1,e.country].filter(function(t){return typeof t==`string`&&t&&t!==e.name});u.push({zone:e.timezone,title:e.name,detail:t.join(`, `)||void 0,place:e.country&&e.country!==e.name?`${e.name}, ${e.country}`:e.name})},s=`${Vt}?name=${encodeURIComponent(t)}&count=${Ut}&language=en&format=json`,c=await fetch(s,{signal:i?.signal});if(!c.ok)throw Error(`HTTP ${c.status}`);var l=await c.json(),u=[];for(var d of Array.isArray(l?.results)?l.results:[])o(d);return Wt.set(n,u),u}finally{clearTimeout(a)}}function Kt(e,t=`SharedToast`){try{var n=valenced.discord.actions.ToastActionCreators,r={text:e};if(typeof n.openMana==`function`){n.openMana(t,r);return}n.open(t,r)}catch{}}var qt=`[Timezones]`,Jt=`TimezonesPicker`;function Yt(e){var t=E(e,Date.now(),q().hour24);return t?`${t.time}${t.otherDay?` ${t.otherDay}`:``} now · ${t.offset}`:`This phone can't show this zone`}var Xt=450;function Zt(e){var[t,n]=valenced.react.React.useState(),r=e.trim(),i=q().placeSearch&&r.length>=2&&!/^[+-]?\d/.test(r)&&!r.includes(`/`);return valenced.react.React.useEffect(function(){if(i){var e=!0,t=setTimeout(function(){Gt(r).then(function(t){return e&&n({q:r,places:t,failed:!1})},function(){return e&&n({q:r,places:[],failed:!0})})},Xt);return function(){e=!1,clearTimeout(t)}}},[r,i]),i?t?.q===r?{places:t.places,state:t.failed?`failed`:`done`}:{places:[],state:`loading`}:{places:[],state:`idle`}}function Qt({current:e,onPick:n}){var{TextInput:r,TableRowGroup:i,TableRow:a}=valenced.discord.design.Design,{ScrollView:o,View:s}=valenced.react.ReactNative,[c,l]=valenced.react.React.useState(``),u=ze(c),d=Zt(c),f=d.places.filter(function(e){return!u.some(function(t){return t.zone===e.zone&&t.title===e.title})}),p=function(r,i){return/*#__PURE__*/ (0,t.jsx)(a,{label:r.zone===e?`${r.title} ✓`:r.title,subLabel:[r.detail,Yt(r.zone)].filter(Boolean).join(` · `),onPress:function(){return n(r)}},`${r.zone}|${r.title}|${i}`)},m=d.state===`loading`?`Searching places…`:d.state===`failed`?`Couldn't search places online.`:d.state===`done`&&f.length===0&&u.length===0?`No place by that name.`:void 0;return/*#__PURE__*/ (0,t.jsxs)(s,{style:{gap:12},children:[/*#__PURE__*/ (0,t.jsx)(r,{placeholder:`A country, city or town, or an offset like +5:30`,autoCapitalize:`none`,autoCorrect:!1,value:c,onChange:l}),/*#__PURE__*/ (0,t.jsx)(o,{style:{maxHeight:320},keyboardShouldPersistTaps:`handled`,nestedScrollEnabled:!0,children:/*#__PURE__*/ (0,t.jsxs)(s,{style:{gap:12},children:[u.length>0&&/*#__PURE__*/ (0,t.jsx)(i,{title:c.trim()?`Countries and zones`:void 0,children:u.map(p)}),(f.length>0||m)&&/*#__PURE__*/ (0,t.jsxs)(i,{title:`Places`,children:[f.map(p),m&&/*#__PURE__*/ (0,t.jsx)(a,{label:m})]}),u.length===0&&d.state===`idle`&&/*#__PURE__*/ (0,t.jsx)(i,{children:/*#__PURE__*/ (0,t.jsx)(a,{label:`No matching timezone`,subLabel:`Try their country, a big city near them, or an offset like -4.`})})]})})]})}function $t(e,n){var{AlertModal:r,AlertActionButton:i}=valenced.discord.design.Design,a=valenced.discord.actions.AlertActionCreators,o=q().people[e],s=o?.zone,c=At(e),l=function(t,r){a.dismissAlert(Jt);try{Ot(e,n,t,r),Kt(t?`${n}: ${r??D(t)}`:`Timezone for ${n} cleared.`,`TimezonesSavedToast`)}catch(e){m(`${qt} saving the timezone failed:`,e)}},u=s?`Set to ${o?.place?`${o.place} (${s})`:s}. Pick another, or clear it.`:c?`The shared list says ${c.zone}. Picking one here overrides it for you.`:`Their local time shows next to their messages. Only you see this.`;a.openAlert(Jt,/*#__PURE__*/ (0,t.jsx)(r,{title:`Timezone for ${n}`,content:u,extraContent:/*#__PURE__*/ (0,t.jsx)(Qt,{current:s??c?.zone,onPick:function(e){return l(e.zone,e.place)}}),actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[s&&/*#__PURE__*/ (0,t.jsx)(i,{text:`Clear`,variant:`destructive`,onPress:function(){return l(void 0)}}),/*#__PURE__*/ (0,t.jsx)(i,{text:`Cancel`,variant:`secondary`,onPress:function(){return a.dismissAlert(Jt)}})]})}))}var en=`[Timezones]`;function tn(e){return/message/i.test(e)&&!/channel|forum|guild|thread/i.test(e)}var nn;function rn(){if(!nn){var{lookupModule:e}=valenced.modules.finders,{withProps:t}=valenced.modules.finders.filters;nn=e(t(`ActionSheetRow`))?.[0]?.ActionSheetRow}return nn}function an(e){var t=/* @__PURE__ */ new Set,n,r=function(e,i){if(!(n||!e||i>30||t.has(e))){if(t.add(e),e.props?.message?.author)n=e.props.message;else if(Array.isArray(e))for(var a of e)r(a,i+1);else r(e.props?.children,i+1)}};return r(e,0),n}function on(e){var n=rn();if(!n)return null;var r=e?.author?.id==null?``:String(e.author.id);if(!r)return null;try{if(r===valenced.discord.flux.Stores.UserStore?.getCurrentUser?.()?.id)return null}catch{}var i=e.author?.globalName??e.author?.username??`this person`,a=At(r),o=a&&E(a.zone,Date.now(),q().hour24),s=o?`Their time: ${o.time}${o.otherDay?` ${o.otherDay}`:``}`:`Set their timezone…`,c=a?`${a.place??D(a.zone)} · ${a.source===`you`?`set by you, tap to change`:a.source===`equicord`?`from Equicord's list, tap to set your own`:`from the shared list, tap to set your own`}`:`Show their local time next to their messages`,{getAssetIdByName:l}=valenced.assets;return/*#__PURE__*/ (0,t.jsx)(n.Group,{children:/*#__PURE__*/ (0,t.jsx)(n,{label:s,subLabel:c,icon:/*#__PURE__*/ (0,t.jsx)(n.Icon,{source:l(`ClockIcon`)}),onPress:function(){try{valenced.discord.actions.ActionSheetActionCreators.hideActionSheet()}catch{}$t(r,i)}})})}function sn(e,t){if(!t)return!1;var n=on(t);if(!n)return!1;var{ActionSheet:r}=valenced.discord.design.Design,i=Bt(e,r,rn()?.Group);if(!i)return!1;var a=i.props.children;return Array.isArray(a)?a.unshift(n):i.props.children=[n,a],!0}var cn=/* @__PURE__ */ new WeakSet;function ln(e,t){if(!e||typeof e.default!=`function`||cn.has(e))return e;var n;return t.push(valenced.patcher.before(e,`default`,function(e){return n=e?.[0]?.message,e})),t.push(valenced.patcher.after(e,`default`,function(e){try{e!=null&&sn(e,n?.author?n:an(e))}catch(e){m(`${en} sheet injection failed:`,e)}return n=void 0,e})),cn.add(e),e}function un(){var{ActionSheetActionCreators:e}=valenced.discord.actions,t=[];return t.push(valenced.patcher.before(e,`openLazy`,function(e){try{var[n,r]=e;typeof r==`string`&&tn(r)&&n&&typeof n.then==`function`&&(e[0]=n.then(function(e){return ln(e,t)}))}catch(e){m(`${en} openLazy hook failed:`,e)}return e})),function(){for(var e of t)try{e()}catch{}}}function dn(e){var{AlertModal:n,AlertActionButton:r}=valenced.discord.design.Design,i=valenced.discord.actions.AlertActionCreators,a=`bleelblep-confirm-${Date.now()}`;i.openAlert(a,/*#__PURE__*/ (0,t.jsx)(n,{title:e.title,content:e.body,actions:/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(r,{text:e.action,variant:`destructive`,onPress:function(){i.dismissAlert(a),e.onConfirm()}}),/*#__PURE__*/ (0,t.jsx)(r,{text:`Cancel`,variant:`secondary`,onPress:function(){return i.dismissAlert(a)}})]})}))}function fn(){try{var e=valenced.discord.design.Design;return e?.TableRow?e:void 0}catch{return}}function pn({label:e,description:n,children:r}){var{View:i,Text:a}=valenced.react.ReactNative;return/*#__PURE__*/ (0,t.jsxs)(i,{style:{gap:8,paddingHorizontal:16,paddingVertical:12},children:[/*#__PURE__*/ (0,t.jsx)(a,{style:{fontSize:16,fontWeight:`600`,color:`#9a9aa2`},children:e}),r,n?/*#__PURE__*/ (0,t.jsx)(a,{style:{fontSize:12,color:`#9a9aa2`,opacity:.8},children:n}):null]})}function mn({label:e,description:n,children:r}){var{View:i}=valenced.react.ReactNative,a=fn();if(!a)return/*#__PURE__*/ (0,t.jsx)(pn,{label:e,description:n,children:r});var{TableRow:o,Text:s}=a;return/*#__PURE__*/ (0,t.jsx)(o,{label:e,subLabel:/*#__PURE__*/ (0,t.jsxs)(i,{style:{gap:8,marginTop:8},children:[r,n?/*#__PURE__*/ (0,t.jsx)(s,{variant:`text-sm/normal`,color:`text-muted`,children:n}):null]})})}function hn({title:e,...n}){var r=fn()?.TableRowGroup;if(!r){var{View:i}=valenced.react.ReactNative;return/*#__PURE__*/ (0,t.jsx)(i,{children:/*#__PURE__*/ (0,t.jsx)(mn,{...n})})}return/*#__PURE__*/ (0,t.jsx)(r,{title:e,children:/*#__PURE__*/ (0,t.jsx)(mn,{...n})})}function $(e,t){try{var n=valenced.discord.flux.Stores.UserStore?.getUser?.(e),r=n?.globalName??n?.global_name??n?.username;if(r)return r}catch{}return t||`User ${e}`}function gn(e,t,n){var r=n??e,i=E(e,Date.now(),t);return i?`${i.time}${i.otherDay?` ${i.otherDay}`:``} · ${r}`:`${r} · can't be shown here`}function _n(){var e=J(),{TableRowGroup:n,TableRow:r}=valenced.discord.design.Design,[a,o]=valenced.react.React.useState(),[,s]=valenced.react.React.useReducer(function(e){return e+1},0);valenced.react.React.useEffect(function(){var e=setInterval(s,6e4);return function(){return clearInterval(e)}},[]);var c=Object.entries(e.people).filter(function(e){return!!e[1]}).sort(function(e,t){return $(e[0],e[1].name).localeCompare($(t[0],t[1].name))});return/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(n,{title:`Timezones you set (${c.length})`,hasIcons:!0,children:c.length===0?/*#__PURE__*/ (0,t.jsx)(r,{label:`No one yet`,subLabel:`Long-press someone's message and choose Set their timezone, or add them by user ID below.`,icon:i(`UserCircleIcon`,`CompassIcon`)}):c.map(function([n,s]){return/*#__PURE__*/ (0,t.jsx)(r,{label:$(n,s.name),subLabel:gn(s.zone,e.hour24,s.place),icon:i(`UserCircleIcon`,`CompassIcon`),onPress:function(){return o(a===n?void 0:n)}},n)})}),a&&e.people[a]&&/*#__PURE__*/ (0,t.jsx)(vn,{id:a})]})}function vn({id:e}){var n=J(),{TableRowGroup:r,TableRow:o}=valenced.discord.design.Design,s=n.people[e],c=$(e,s?.name);return/*#__PURE__*/ (0,t.jsxs)(r,{title:c,hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(o,{label:`Change timezone`,subLabel:s?s.place??D(s.zone):void 0,icon:i(`PencilIcon`,`ic_edit`),onPress:function(){return $t(e,c)}}),/*#__PURE__*/ (0,t.jsx)(o,{label:`Remove`,subLabel:n.sharedLookup?`Their time goes back to the shared list, if they are on it.`:void 0,variant:`danger`,icon:a(`TrashIcon`),onPress:function(){return dn({title:`Remove ${c}?`,body:`Their local time stops showing next to their messages.`,action:`Remove`,onConfirm:function(){return Ot(e,c,void 0)}})}})]})}function yn(){var e=J(),{TableRowGroup:n,TableRow:r,TextInput:a}=valenced.discord.design.Design,[o,s]=valenced.react.React.useState(``),c=o.trim(),l=/^\d{15,21}$/.test(c);return/*#__PURE__*/ (0,t.jsxs)(t.Fragment,{children:[/*#__PURE__*/ (0,t.jsx)(hn,{label:`Add by user ID`,description:`Developer Mode lets you copy anyone's ID from their profile.`,children:/*#__PURE__*/ (0,t.jsx)(a,{placeholder:`123456789012345678`,value:o,onChange:s,keyboardType:`number-pad`})}),/*#__PURE__*/ (0,t.jsxs)(n,{hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(r,{label:`Choose their timezone`,icon:i(`ClockIcon`,`PlusSmallIcon`),arrow:!0,disabled:!l,onPress:function(){$t(c,$(c)),s(``)}}),e.sharedLookup&&/*#__PURE__*/ (0,t.jsx)(r,{label:`Look them up again`,subLabel:`Ask the shared list about this ID now.`,icon:i(`RefreshIcon`,`ArrowAngleLeftUpIcon`),disabled:!l,onPress:function(){gt(c),Kt(`Looking them up…`,`TimezonesRefetchToast`)}})]})]})}function bn({api:e}){Dt(e?.jsonStorage),ie();var n=J(),{Page:r}=valenced.components,{ScrollView:a,View:o}=valenced.react.ReactNative,{Stack:s,Card:l,Text:u,TableRowGroup:d,TableSwitchRow:f}=valenced.discord.design.Design;return/*#__PURE__*/ (0,t.jsx)(r,{children:/*#__PURE__*/ (0,t.jsx)(a,{contentContainerStyle:{paddingBottom:c()},children:/*#__PURE__*/ (0,t.jsxs)(s,{spacing:24,children:[/*#__PURE__*/ (0,t.jsx)(l,{variant:`secondary`,border:`none`,children:/*#__PURE__*/ (0,t.jsxs)(o,{style:{paddingHorizontal:16,paddingVertical:12},children:[/*#__PURE__*/ (0,t.jsx)(u,{color:`text-default`,variant:`text-md/semibold`,children:`Their time, beside their messages`}),/*#__PURE__*/ (0,t.jsx)(u,{color:`text-muted`,variant:`text-sm/normal`,style:{marginTop:8},children:`Long-press someone's message to set their timezone. Only you see it.`})]})}),!Oe()&&/*#__PURE__*/ (0,t.jsx)(u,{color:`text-feedback-critical`,variant:`text-sm/normal`,children:`This Discord build can't work out city timezones, so only offsets like +5:30 show.`}),/*#__PURE__*/ (0,t.jsxs)(d,{title:`Chat`,hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(f,{label:`Show in chat`,subLabel:`Their local time after the timestamp on their messages.`,icon:i(`ClockIcon`,`ic_clock`),value:n.showInChat,onValueChange:function(e){return Y({showInChat:e})}}),/*#__PURE__*/ (0,t.jsx)(f,{label:`24-hour time`,subLabel:n.hour24?`15:02`:`3:02 PM`,icon:i(`TimerIcon`,`ClockIcon`),value:n.hour24,onValueChange:function(e){return Y({hour24:e})}}),/*#__PURE__*/ (0,t.jsx)(f,{label:`Show their day`,subLabel:`Add the weekday when it's a different day for them, like 3:02 AM Tue.`,icon:i(`CalendarIcon`,`ClockIcon`),value:n.showDay,onValueChange:function(e){return Y({showDay:e})}})]}),/*#__PURE__*/ (0,t.jsxs)(d,{title:`Lookups`,hasIcons:!0,children:[/*#__PURE__*/ (0,t.jsx)(f,{label:`Use the shared timezone list`,subLabel:`For people you haven't set, ask timezonedb.catvibers.me, where people add their own timezone. Sends it the IDs of people whose messages you see.`,icon:i(`GlobeEarthIcon`,`ic_link`),value:n.sharedLookup,onValueChange:function(e){return Y({sharedLookup:e})}}),/*#__PURE__*/ (0,t.jsx)(f,{label:`Also use Equicord's list`,subLabel:`For people still without one, read the timezones people set in Equicord (timezone.creations.works). Downloads the whole list about once an hour; sends nothing about you. Read only: set yours from Equicord on desktop.`,icon:i(`GlobeEarthIcon`,`ic_link`),value:n.equicordLookup,onValueChange:function(e){return Y({equicordLookup:e})}}),/*#__PURE__*/ (0,t.jsx)(f,{label:`Search places online`,subLabel:`Find any town or city when picking a timezone, through Open-Meteo. Sends only what you type. Countries and big cities work without it.`,icon:i(`MagnifyingGlassIcon`,`CompassIcon`),value:n.placeSearch,onValueChange:function(e){return Y({placeSearch:e})}})]}),/*#__PURE__*/ (0,t.jsx)(_n,{}),/*#__PURE__*/ (0,t.jsx)(yn,{})]})})})}var xn=`[Timezones]`;function Sn(e,t,n){try{e(n())}catch(e){m(`${xn} ${t} failed:`,e)}}return e.default=plugin({jsonStorage:{load:!0,default:H},start(e){if(p(e.plugin),e.cleanup(function(){return p(void 0)}),e.plugin.startedLate)e.plugin.requireReload();else{var{cleanup:t,jsonStorage:n}=e;Et(n),t(function(){return Et(void 0)}),bt(),t(xt),tt(),t(nt),Sn(t,`changelog`,function(){return ne(e,fe)}),Sn(t,`message cache`,ve),Sn(t,`chat timestamp`,zt),Sn(t,`message sheet`,un)}},stop(e){xt(),nt(),e.plugin.requireReload()},SettingsComponent:bn}),e})({},valenced.react.ReactJSXRuntime);